import React from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import { cn } from '../../utils/cn';
import Icon from '../AppIcon';

const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap rounded-lg text-sm font-medium ring-offset-background transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] transform',
  {
    variants: {
      variant: {
        default: 'bg-gradient-to-r from-primary via-primary to-primary/95 text-primary-foreground hover:shadow-lg hover:from-primary/90 hover:to-primary/85 shadow-md',
        destructive: 'bg-gradient-to-r from-destructive to-destructive/95 text-destructive-foreground hover:shadow-lg hover:from-destructive/90 hover:to-destructive/85 shadow-md',
        outline: 'border-2 border-border bg-white hover:bg-accent/5 hover:text-accent-foreground hover:border-accent/30 shadow-sm hover:shadow-md',
        secondary: 'bg-gradient-to-r from-secondary to-secondary/95 text-secondary-foreground hover:shadow-lg hover:from-secondary/90 hover:to-secondary/85 shadow-md',
        ghost: 'hover:bg-accent/10 hover:text-accent-foreground rounded-md',
        link: 'text-primary underline-offset-4 hover:underline p-0 h-auto font-normal',
        success: 'bg-gradient-to-r from-success to-success/95 text-success-foreground hover:shadow-lg hover:from-success/90 hover:to-success/85 shadow-md',
        warning: 'bg-gradient-to-r from-warning to-warning/95 text-warning-foreground hover:shadow-lg hover:from-warning/90 hover:to-warning/85 shadow-md',
      },
      size: {
        default: 'h-10 px-4 py-2',
        sm: 'h-9 rounded-md px-3',
        lg: 'h-11 rounded-lg px-8 text-base font-semibold',
        xl: 'h-12 rounded-lg px-10 text-lg font-semibold',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

const Button = React.forwardRef(({
  className,
  variant,
  size,
  asChild = false,
  loading = false,
  disabled = false,
  fullWidth = false,
  iconName,
  iconPosition = 'left',
  iconSize = 16,
  children,
  ...props
}, ref) => {
  const Comp = asChild ? Slot : 'button';
  
  const isDisabled = disabled || loading;
  
  return (
    <Comp
      className={cn(
        buttonVariants({ variant, size, className }),
        fullWidth && 'w-full',
        isDisabled && 'opacity-60 cursor-not-allowed'
      )}
      ref={ref}
      disabled={isDisabled}
      {...props}
    >
      {loading && (
        <Icon 
          name="Loader2" 
          size={iconSize} 
          className="mr-2 animate-spin" 
        />
      )}
      {!loading && iconName && iconPosition === 'left' && (
        <Icon 
          name={iconName} 
          size={iconSize} 
          className="mr-2" 
        />
      )}
      <span className="truncate">{children}</span>
      {!loading && iconName && iconPosition === 'right' && (
        <Icon 
          name={iconName} 
          size={iconSize} 
          className="ml-2" 
        />
      )}
    </Comp>
  );
});

Button.displayName = 'Button';

export default Button;