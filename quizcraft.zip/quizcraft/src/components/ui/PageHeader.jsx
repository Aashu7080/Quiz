import React from 'react';
import Icon from '../AppIcon';

const PageHeader = ({ 
  title, 
  subtitle, 
  breadcrumbs = [], 
  actions = [], 
  showBackButton = false, 
  onBack = () => {} 
}) => {
  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Breadcrumbs */}
        {breadcrumbs?.length > 0 && (
          <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-4">
            {breadcrumbs?.map((crumb, index) => (
              <React.Fragment key={index}>
                {index > 0 && <Icon name="ChevronRight" size={14} />}
                {crumb?.href ? (
                  <button
                    onClick={() => crumb?.onClick && crumb?.onClick()}
                    className="hover:text-foreground transition-colors duration-200"
                  >
                    {crumb?.label}
                  </button>
                ) : (
                  <span className="text-foreground font-medium">{crumb?.label}</span>
                )}
              </React.Fragment>
            ))}
          </nav>
        )}

        {/* Header Content */}
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-4">
            {/* Back Button */}
            {showBackButton && (
              <button
                onClick={onBack}
                className="mt-1 p-2 rounded-md hover:bg-muted transition-colors duration-200"
              >
                <Icon name="ArrowLeft" size={20} />
              </button>
            )}

            {/* Title and Subtitle */}
            <div>
              <h1 className="text-2xl font-heading font-semibold text-foreground">
                {title}
              </h1>
              {subtitle && (
                <p className="mt-1 text-muted-foreground font-body">
                  {subtitle}
                </p>
              )}
            </div>
          </div>

          {/* Actions */}
          {actions?.length > 0 && (
            <div className="flex items-center space-x-3">
              {actions?.map((action, index) => (
                <div key={index}>
                  {action}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PageHeader;