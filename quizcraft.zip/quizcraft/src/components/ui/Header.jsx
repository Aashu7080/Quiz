import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ user, onNavigate, currentPath }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('isAuthenticated');
    navigate('/login');
  };

  const navigationItems = [
    {
      label: 'Dashboard',
      path: user?.role === 'teacher' ? '/teacher-dashboard' : '/student-dashboard',
      icon: 'LayoutDashboard'
    },
    {
      label: 'Quiz Creation',
      path: '/quiz-creation',
      icon: 'Plus',
      teacherOnly: true
    },
    {
      label: 'Settings',
      path: '/account-settings',
      icon: 'Settings'
    }
  ];

  const filteredNavItems = navigationItems?.filter(item => 
    !item?.teacherOnly || user?.role === 'teacher'
  );

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
      isScrolled 
        ? 'bg-card/95 backdrop-blur-md border-b border-border shadow-medium' 
        : 'bg-card/80 backdrop-blur-sm border-b border-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Enhanced Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary via-primary/90 to-accent rounded-xl flex items-center justify-center shadow-md transform hover:scale-105 transition-transform duration-200">
              <Icon name="BookOpen" size={20} color="white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground tracking-tight">QuizCraft</h1>
              <div className="text-xs text-muted-foreground font-medium">
                by @Sudais_alam
              </div>
            </div>
          </div>

          {/* Enhanced Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {filteredNavItems?.map((item) => {
              const isActive = location?.pathname === item?.path;
              return (
                <button
                  key={item?.path}
                  onClick={() => navigate(item?.path)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-primary/10 text-primary border border-primary/20 shadow-sm'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                >
                  <Icon name={item?.icon} size={16} />
                  <span>{item?.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Enhanced User Menu */}
          <div className="flex items-center space-x-4">
            {/* Notification Bell */}
            <Button
              variant="ghost"
              size="icon"
              className="relative hover:bg-muted/50"
            >
              <Icon name="Bell" size={18} />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"></span>
            </Button>

            {/* User Profile Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted/50 transition-colors duration-200"
              >
                <img
                  src={user?.avatar || '/api/placeholder/32/32'}
                  alt={user?.name}
                  className="w-8 h-8 rounded-full border-2 border-border shadow-sm"
                />
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium text-foreground">
                    {user?.name}
                  </div>
                  <div className="text-xs text-muted-foreground capitalize">
                    {user?.role}
                  </div>
                </div>
                <Icon 
                  name="ChevronDown" 
                  size={16} 
                  className={`text-muted-foreground transition-transform duration-200 ${
                    showUserMenu ? 'rotate-180' : ''
                  }`} 
                />
              </button>

              {/* Enhanced Dropdown Menu */}
              {showUserMenu && (
                <div className="absolute right-0 top-full mt-2 w-56 bg-card border border-border rounded-xl shadow-strong py-2 z-50">
                  <div className="px-4 py-3 border-b border-border">
                    <div className="font-medium text-foreground">{user?.name}</div>
                    <div className="text-sm text-muted-foreground">{user?.email}</div>
                    <div className="text-xs text-primary/70 mt-1 capitalize">
                      {user?.subscription} Plan
                    </div>
                  </div>
                  
                  <div className="py-1">
                    <button
                      onClick={() => {
                        navigate('/account-settings');
                        setShowUserMenu(false);
                      }}
                      className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-foreground hover:bg-muted/50 transition-colors duration-200"
                    >
                      <Icon name="User" size={16} />
                      <span>Profile Settings</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        // Navigate to billing/upgrade page
                        setShowUserMenu(false);
                      }}
                      className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-foreground hover:bg-muted/50 transition-colors duration-200"
                    >
                      <Icon name="Crown" size={16} />
                      <span>Upgrade Plan</span>
                    </button>
                    
                    <div className="border-t border-border my-1"></div>
                    
                    <button
                      onClick={() => {
                        handleLogout();
                        setShowUserMenu(false);
                      }}
                      className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-error hover:bg-error/10 transition-colors duration-200"
                    >
                      <Icon name="LogOut" size={16} />
                      <span>Sign Out</span>
                    </button>
                  </div>
                  
                  {/* Credit footer in dropdown */}
                  <div className="px-4 py-2 border-t border-border/50">
                    <div className="text-xs text-muted-foreground/60 text-center">
                      <a 
                        href="https://t.me/sudaisfuseX" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="hover:text-primary transition-colors duration-200"
                      >
                        Built with ❤️ by @Sudais_alam
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Mobile Navigation */}
      <div className="md:hidden border-t border-border bg-card/95 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-around py-2">
            {filteredNavItems?.map((item) => {
              const isActive = location?.pathname === item?.path;
              return (
                <button
                  key={item?.path}
                  onClick={() => navigate(item?.path)}
                  className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                    isActive
                      ? 'text-primary bg-primary/10' :'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon name={item?.icon} size={16} />
                  <span className="text-xs font-medium">{item?.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;