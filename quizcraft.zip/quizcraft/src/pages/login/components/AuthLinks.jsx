import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';


const AuthLinks = ({ onNavigate }) => {
  return (
    <div className="space-y-4">
      <div className="text-center">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('/forgot-password')}
          iconName="HelpCircle"
          iconPosition="left"
          iconSize={16}
          className="text-muted-foreground hover:text-primary transition-colors duration-200"
        >
          Forgot your password?
        </Button>
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border/60" />
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-3 bg-card text-muted-foreground/80 font-medium">New to QuizCraft?</span>
        </div>
      </div>

      <div className="text-center">
        <Button
          variant="outline"
          size="lg"
          fullWidth
          onClick={() => onNavigate('/register')}
          iconName="UserPlus"
          iconPosition="left"
          className="bg-gradient-to-r from-white to-gray-50 hover:from-gray-50 hover:to-gray-100 border-2 hover:border-primary/20 transition-all duration-200 text-foreground hover:text-primary shadow-sm hover:shadow-md"
        >
          Create Your Account
        </Button>
      </div>
      
      {/* Enhanced demo credentials section */}
      <div className="mt-6 p-4 bg-gradient-to-r from-blue-50/50 to-indigo-50/50 rounded-lg border border-blue-100/60">
        <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center">
          <Icon name="Key" size={14} className="mr-2 text-blue-600" />
          Demo Credentials
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="bg-white/60 p-3 rounded-md border border-blue-100/50">
            <div className="font-semibold text-blue-700 mb-1">Teacher Demo</div>
            <div className="space-y-1 text-muted-foreground">
              <div><strong>Email:</strong> teacher@quizcraft.com</div>
              <div><strong>Password:</strong> teacher123</div>
            </div>
          </div>
          <div className="bg-white/60 p-3 rounded-md border border-blue-100/50">
            <div className="font-semibold text-green-700 mb-1">Student Demo</div>
            <div className="space-y-1 text-muted-foreground">
              <div><strong>Email:</strong> student@quizcraft.com</div>
              <div><strong>Password:</strong> student123</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLinks;