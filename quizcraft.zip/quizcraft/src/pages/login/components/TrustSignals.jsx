import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  const trustBadges = [
    {
      icon: 'Shield',
      title: 'Enterprise Security',
      description: 'Bank-grade SSL encryption',
      color: 'text-emerald-600'
    },
    {
      icon: 'Award',
      title: 'Education Certified',
      description: 'Trusted by 15,000+ educators',
      color: 'text-blue-600'
    },
    {
      icon: 'Users',
      title: 'Student Approved',
      description: 'Used by 100,000+ students',
      color: 'text-purple-600'
    }
  ];

  return (
    <div className="mt-8 pt-6 border-t border-border">
      {/* Enhanced trust signals with better styling */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {trustBadges?.map((badge, index) => (
          <div key={index} className="group flex items-center space-x-3 p-3 bg-gradient-to-r from-muted/30 to-muted/50 rounded-lg hover:from-muted/50 hover:to-muted/70 transition-all duration-200 border border-border/50 hover:border-border">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow duration-200 border border-border/20">
                <Icon name={badge?.icon} size={14} className={badge?.color} />
              </div>
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors duration-200">{badge?.title}</p>
              <p className="text-xs text-muted-foreground leading-tight">{badge?.description}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Footer attribution for Sudais */}
      <div className="mt-6 pt-4 border-t border-border/30">
        <div className="text-center">
          <p className="text-xs text-muted-foreground/70 mb-2">Powered by innovative technology</p>
          <div className="flex items-center justify-center space-x-2">
            <div className="w-6 h-6 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
              <Icon name="Zap" size={12} color="white" />
            </div>
            <span className="text-xs font-medium text-foreground">QuizCraft Pro</span>
            <span className="text-xs text-muted-foreground/60">•</span>
            <a 
              href="https://t.me/sudaisfuseX" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs text-primary/70 hover:text-primary transition-colors duration-200"
            >
              Created by Sudais Alam
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrustSignals;