import React from 'react';
import Icon from '../../../components/AppIcon';

const LoginHeader = () => {
  return (
    <div className="text-center mb-8">
      <div className="flex justify-center mb-6">
        <div className="w-16 h-16 bg-gradient-to-br from-primary via-primary/90 to-accent rounded-xl flex items-center justify-center shadow-lg transform hover:scale-105 transition-transform duration-200">
          <Icon name="BookOpen" size={32} color="white" />
        </div>
      </div>
      
      <h1 className="text-3xl font-heading font-semibold text-foreground mb-2 tracking-tight">
        Welcome to QuizCraft
      </h1>
      
      <p className="text-muted-foreground font-body text-base leading-relaxed max-w-sm mx-auto">
        The most advanced platform for creating and taking interactive quizzes
      </p>
      
      {/* Professional credit attribution */}
      <div className="mt-6 pt-4 border-t border-border/50">
        <div className="flex items-center justify-center space-x-2 text-xs text-muted-foreground/80">
          <Icon name="Code" size={12} className="opacity-60" />
          <span>Developed by</span>
          <a 
            href="https://t.me/sudaisfuseX" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-primary/80 hover:text-primary font-medium transition-colors duration-200 flex items-center space-x-1"
          >
            <span>@Sudais_alam</span>
            <Icon name="ExternalLink" size={10} />
          </a>
        </div>
      </div>
    </div>
  );
};

export default LoginHeader;