import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import LoginHeader from './components/LoginHeader';
import AuthLinks from './components/AuthLinks';
import TrustSignals from './components/TrustSignals';

const LoginPage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Mock credentials for different user types
  const mockCredentials = {
    teacher: {
      email: 'teacher@quizcraft.com',
      password: 'teacher123'
    },
    student: {
      email: 'student@quizcraft.com',
      password: 'student123'
    }
  };

  const handleLogin = async (formData) => {
    setLoading(true);
    setError(null);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      const { email, password, role } = formData;
      const validCredentials = mockCredentials?.[role];

      if (email === validCredentials?.email && password === validCredentials?.password) {
        // Mock user data
        const userData = {
          id: role === 'teacher' ? 'teacher_001' : 'student_001',
          name: role === 'teacher' ? 'Dr. Sarah Johnson' : 'Alex Thompson',
          email: email,
          role: role,
          avatar: `https://randomuser.me/api/portraits/${role === 'teacher' ? 'women' : 'men'}/${role === 'teacher' ? '44' : '32'}.jpg`,
          joinedDate: '2024-01-15',
          subscription: role === 'teacher' ? 'premium' : 'free'
        };

        // Store user data in localStorage (in real app, this would be handled by auth context)
        localStorage.setItem('user', JSON.stringify(userData));
        localStorage.setItem('isAuthenticated', 'true');

        // Navigate to appropriate dashboard
        if (role === 'teacher') {
          navigate('/teacher-dashboard');
        } else {
          navigate('/student-dashboard');
        }
      } else {
        setError(`Invalid credentials. Use ${validCredentials?.email} / ${validCredentials?.password} for ${role} login.`);
      }
    } catch (err) {
      setError('An error occurred during login. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleNavigation = (path) => {
    navigate(path);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-card border border-border rounded-2xl shadow-strong p-8 backdrop-blur-sm">
          <LoginHeader />
          
          <LoginForm
            onSubmit={handleLogin}
            loading={loading}
            error={error}
          />
          
          <div className="mt-8">
            <AuthLinks onNavigate={handleNavigation} />
          </div>
          
          <TrustSignals />
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground/80 leading-relaxed">
            By signing in, you agree to our Terms of Service and Privacy Policy
          </p>
          {/* Additional credit mention */}
          <div className="mt-3 text-center">
            <a 
              href="https://t.me/sudaisfuseX" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs text-primary/60 hover:text-primary transition-colors duration-200 font-medium"
            >
              💫 Experience the future of quiz creation - by @Sudais_alam
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;