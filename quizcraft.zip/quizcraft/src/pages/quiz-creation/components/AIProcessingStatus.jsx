import React from 'react';
import Icon from '../../../components/AppIcon';

const AIProcessingStatus = ({ 
  isProcessing, 
  progress = 0, 
  currentStep = '', 
  estimatedTime = 0,
  error = null 
}) => {
  const processingSteps = [
    { id: 'upload', label: 'Processing uploaded files', icon: 'Upload' },
    { id: 'analyze', label: 'Analyzing content structure', icon: 'Search' },
    { id: 'extract', label: 'Extracting key concepts', icon: 'Brain' },
    { id: 'generate', label: 'Generating questions', icon: 'Zap' },
    { id: 'review', label: 'Reviewing and formatting', icon: 'CheckCircle' }
  ];

  const getCurrentStepIndex = () => {
    return processingSteps?.findIndex(step => step?.id === currentStep);
  };

  const formatTime = (seconds) => {
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  if (!isProcessing && !error) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Brain" size={32} className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">AI Quiz Generator Ready</h3>
          <p className="text-sm text-muted-foreground">
            Upload your educational content to start generating quiz questions automatically.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-card rounded-lg border border-error/20 p-6">
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-error/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="AlertCircle" size={32} className="text-error" />
          </div>
          <h3 className="text-lg font-semibold text-error mb-2">Processing Error</h3>
          <p className="text-sm text-muted-foreground mb-4">{error}</p>
          <button className="text-sm text-primary hover:text-primary/80 font-medium">
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">AI Processing</h3>
        <p className="text-sm text-muted-foreground">
          Our AI is analyzing your content and generating quiz questions.
        </p>
      </div>
      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Overall Progress</span>
          <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-3">
          <div
            className="bg-primary h-3 rounded-full transition-all duration-500 relative overflow-hidden"
            style={{ width: `${progress}%` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
          </div>
        </div>
      </div>
      {/* Processing Steps */}
      <div className="space-y-4 mb-6">
        {processingSteps?.map((step, index) => {
          const currentStepIndex = getCurrentStepIndex();
          const isCompleted = index < currentStepIndex;
          const isCurrent = index === currentStepIndex;
          const isPending = index > currentStepIndex;

          return (
            <div
              key={step?.id}
              className={`flex items-center space-x-3 p-3 rounded-lg transition-colors duration-200 ${
                isCurrent ? 'bg-primary/10 border border-primary/20' : 
                isCompleted ? 'bg-success/10' : 'bg-muted/50'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  isCompleted ? 'bg-success text-white' : isCurrent ?'bg-primary text-white': 'bg-muted-foreground/20 text-muted-foreground'
                }`}
              >
                {isCompleted ? (
                  <Icon name="Check" size={16} />
                ) : isCurrent ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Icon name={step?.icon} size={16} />
                )}
              </div>
              <div className="flex-1">
                <p className={`text-sm font-medium ${
                  isCurrent ? 'text-primary' : 
                  isCompleted ? 'text-success': 'text-muted-foreground'
                }`}>
                  {step?.label}
                </p>
              </div>
              {isCurrent && (
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <Icon name="Clock" size={12} />
                  <span>Processing...</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {/* Estimated Time */}
      {estimatedTime > 0 && (
        <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
          <Icon name="Clock" size={16} />
          <span>Estimated time remaining: {formatTime(estimatedTime)}</span>
        </div>
      )}
      {/* Processing Tips */}
      <div className="mt-6 p-4 bg-muted/50 rounded-lg">
        <h4 className="text-sm font-medium text-foreground mb-2">Processing Tips</h4>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>• Larger documents may take longer to process</li>
          <li>• Complex content generates more detailed questions</li>
          <li>• You can edit questions after generation completes</li>
        </ul>
      </div>
    </div>
  );
};

export default AIProcessingStatus;