import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const QuizSaveOptions = ({ onSaveQuiz, onShareQuiz, isLoading = false }) => {
  const [quizDetails, setQuizDetails] = useState({
    title: '',
    description: '',
    category: 'general',
    isPublic: false,
    allowAnonymous: true,
    sendNotifications: false
  });

  const [shareOptions, setShareOptions] = useState({
    generateLink: true,
    emailStudents: false,
    addToLibrary: true,
    exportPDF: false
  });

  const categories = [
    { value: 'general', label: 'General Knowledge' },
    { value: 'science', label: 'Science' },
    { value: 'math', label: 'Mathematics' },
    { value: 'history', label: 'History' },
    { value: 'literature', label: 'Literature' },
    { value: 'language', label: 'Language Arts' },
    { value: 'other', label: 'Other' }
  ];

  const handleSave = () => {
    if (!quizDetails?.title?.trim()) {
      alert('Please enter a quiz title');
      return;
    }
    
    onSaveQuiz({
      ...quizDetails,
      shareOptions,
      savedAt: new Date()?.toISOString()
    });
  };

  const handleShare = () => {
    if (!quizDetails?.title?.trim()) {
      alert('Please enter a quiz title before sharing');
      return;
    }
    
    onShareQuiz({
      ...quizDetails,
      shareOptions,
      sharedAt: new Date()?.toISOString()
    });
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Save & Share Quiz</h3>
        <p className="text-sm text-muted-foreground">
          Configure your quiz details and sharing preferences before saving.
        </p>
      </div>
      <div className="space-y-6">
        {/* Quiz Details */}
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-foreground">Quiz Information</h4>
          
          <Input
            label="Quiz Title"
            type="text"
            placeholder="e.g., Photosynthesis Chapter Test"
            value={quizDetails?.title}
            onChange={(e) => setQuizDetails(prev => ({ ...prev, title: e?.target?.value }))}
            required
            description="Give your quiz a descriptive title"
          />

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Description (Optional)
            </label>
            <textarea
              className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              rows="3"
              placeholder="Provide additional context or instructions for students..."
              value={quizDetails?.description}
              onChange={(e) => setQuizDetails(prev => ({ ...prev, description: e?.target?.value }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Category</label>
            <select
              value={quizDetails?.category}
              onChange={(e) => setQuizDetails(prev => ({ ...prev, category: e?.target?.value }))}
              className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {categories?.map(category => (
                <option key={category?.value} value={category?.value}>
                  {category?.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Privacy Settings */}
        <div className="border-t border-border pt-6">
          <h4 className="text-sm font-semibold text-foreground mb-4">Privacy Settings</h4>
          
          <div className="space-y-3">
            <Checkbox
              label="Make quiz publicly discoverable"
              description="Other teachers can find and use this quiz in the community library"
              checked={quizDetails?.isPublic}
              onChange={(e) => setQuizDetails(prev => ({ ...prev, isPublic: e?.target?.checked }))}
            />

            <Checkbox
              label="Allow anonymous attempts"
              description="Students can take the quiz without logging in"
              checked={quizDetails?.allowAnonymous}
              onChange={(e) => setQuizDetails(prev => ({ ...prev, allowAnonymous: e?.target?.checked }))}
            />

            <Checkbox
              label="Send completion notifications"
              description="Get notified when students complete the quiz"
              checked={quizDetails?.sendNotifications}
              onChange={(e) => setQuizDetails(prev => ({ ...prev, sendNotifications: e?.target?.checked }))}
            />
          </div>
        </div>

        {/* Share Options */}
        <div className="border-t border-border pt-6">
          <h4 className="text-sm font-semibold text-foreground mb-4">Sharing Options</h4>
          
          <div className="space-y-3">
            <Checkbox
              label="Generate shareable link"
              description="Create a direct link students can use to access the quiz"
              checked={shareOptions?.generateLink}
              onChange={(e) => setShareOptions(prev => ({ ...prev, generateLink: e?.target?.checked }))}
            />

            <Checkbox
              label="Add to my quiz library"
              description="Save this quiz to your personal library for future use"
              checked={shareOptions?.addToLibrary}
              onChange={(e) => setShareOptions(prev => ({ ...prev, addToLibrary: e?.target?.checked }))}
            />

            <div className="flex items-start space-x-3">
              <Checkbox
                label="Export as PDF"
                description="Generate a PDF version for offline use"
                checked={shareOptions?.exportPDF}
                onChange={(e) => setShareOptions(prev => ({ ...prev, exportPDF: e?.target?.checked }))}
              />
              <div className="ml-6 mt-1">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent">
                  <Icon name="Crown" size={12} className="mr-1" />
                  Premium
                </span>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                label="Email to students"
                description="Send quiz invitations directly to student email addresses"
                checked={shareOptions?.emailStudents}
                onChange={(e) => setShareOptions(prev => ({ ...prev, emailStudents: e?.target?.checked }))}
              />
              <div className="ml-6 mt-1">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent">
                  <Icon name="Crown" size={12} className="mr-1" />
                  Premium
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-muted/50 rounded-lg p-4">
          <h5 className="text-sm font-medium text-foreground mb-3">Quiz Summary</h5>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-lg font-semibold text-primary">12</div>
              <div className="text-xs text-muted-foreground">Questions</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-primary">30m</div>
              <div className="text-xs text-muted-foreground">Time Limit</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-primary">Mixed</div>
              <div className="text-xs text-muted-foreground">Difficulty</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-primary">MCQ</div>
              <div className="text-xs text-muted-foreground">Question Type</div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <Button
            variant="outline"
            onClick={() => setQuizDetails({ title: '', description: '', category: 'general', isPublic: false, allowAnonymous: true, sendNotifications: false })}
            disabled={isLoading}
            className="flex-1"
          >
            Reset Form
          </Button>
          
          <Button
            variant="secondary"
            onClick={handleSave}
            loading={isLoading}
            iconName="Save"
            iconPosition="left"
            className="flex-1"
          >
            Save as Draft
          </Button>
          
          <Button
            variant="default"
            onClick={handleShare}
            loading={isLoading}
            iconName="Share"
            iconPosition="left"
            className="flex-1"
          >
            Save & Share
          </Button>
        </div>

        {/* Premium Upgrade Notice */}
        <div className="bg-gradient-to-r from-accent/10 to-primary/10 border border-accent/20 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
              <Icon name="Crown" size={16} className="text-white" />
            </div>
            <div className="flex-1">
              <h5 className="text-sm font-medium text-foreground mb-1">Unlock Premium Features</h5>
              <p className="text-xs text-muted-foreground mb-3">
                Get PDF exports, email distribution, advanced analytics, and LMS integration with QuizCraft Premium.
              </p>
              <Button variant="outline" size="sm">
                Upgrade Now
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizSaveOptions;