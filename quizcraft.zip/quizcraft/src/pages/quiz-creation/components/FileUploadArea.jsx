import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FileUploadArea = ({ onFileUpload, isProcessing }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const fileInputRef = useRef(null);

  const supportedFormats = [
    { extension: 'PDF', icon: 'FileText', color: 'text-red-500' },
    { extension: 'DOCX', icon: 'FileText', color: 'text-blue-500' },
    { extension: 'TXT', icon: 'File', color: 'text-gray-500' }
  ];

  const handleDragOver = (e) => {
    e?.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e?.dataTransfer?.files);
    processFiles(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e?.target?.files);
    processFiles(files);
  };

  const processFiles = (files) => {
    const validFiles = files?.filter(file => {
      const extension = file?.name?.split('.')?.pop()?.toLowerCase();
      return ['pdf', 'docx', 'txt']?.includes(extension);
    });

    if (validFiles?.length === 0) {
      alert('Please upload PDF, DOCX, or TXT files only.');
      return;
    }

    // Simulate upload progress
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadedFiles(prev => [...prev, ...validFiles?.map(file => ({
            id: Date.now() + Math.random(),
            name: file?.name,
            size: file?.size,
            type: file?.type,
            uploadedAt: new Date()
          }))]);
          onFileUpload(validFiles);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const removeFile = (fileId) => {
    setUploadedFiles(prev => prev?.filter(file => file?.id !== fileId));
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i))?.toFixed(2)) + ' ' + sizes?.[i];
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Upload Educational Content</h3>
        <p className="text-sm text-muted-foreground">
          Upload your notes, documents, or study materials to generate quiz questions automatically.
        </p>
      </div>
      {/* Upload Area */}
      <div
        className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors duration-200 ${
          isDragOver
            ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 hover:bg-muted/50'
        } ${isProcessing ? 'opacity-50 pointer-events-none' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".pdf,.docx,.txt"
          onChange={handleFileSelect}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isProcessing}
        />

        <div className="flex flex-col items-center space-y-4">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <Icon name="Upload" size={32} className="text-primary" />
          </div>
          
          <div>
            <p className="text-lg font-medium text-foreground mb-2">
              Drop your files here or click to browse
            </p>
            <p className="text-sm text-muted-foreground">
              Maximum file size: 10MB per file
            </p>
          </div>

          <Button
            variant="outline"
            onClick={() => fileInputRef?.current?.click()}
            disabled={isProcessing}
            iconName="FolderOpen"
            iconPosition="left"
          >
            Choose Files
          </Button>
        </div>
      </div>
      {/* Supported Formats */}
      <div className="mt-4">
        <p className="text-xs text-muted-foreground mb-2">Supported formats:</p>
        <div className="flex items-center space-x-4">
          {supportedFormats?.map((format) => (
            <div key={format?.extension} className="flex items-center space-x-1">
              <Icon name={format?.icon} size={16} className={format?.color} />
              <span className="text-xs text-muted-foreground">{format?.extension}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Upload Progress */}
      {uploadProgress > 0 && uploadProgress < 100 && (
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-foreground">Uploading files...</span>
            <span className="text-sm text-muted-foreground">{uploadProgress}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        </div>
      )}
      {/* Uploaded Files */}
      {uploadedFiles?.length > 0 && (
        <div className="mt-6">
          <h4 className="text-sm font-medium text-foreground mb-3">Uploaded Files</h4>
          <div className="space-y-2">
            {uploadedFiles?.map((file) => (
              <div
                key={file?.id}
                className="flex items-center justify-between p-3 bg-muted rounded-md"
              >
                <div className="flex items-center space-x-3">
                  <Icon name="FileText" size={16} className="text-primary" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{file?.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(file?.size)} • Uploaded {file?.uploadedAt?.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeFile(file?.id)}
                  iconName="X"
                  className="text-muted-foreground hover:text-error"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUploadArea;