import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const QuizParametersForm = ({ parameters, onParametersChange, disabled }) => {
  const [localParameters, setLocalParameters] = useState({
    questionCount: 10,
    difficulty: 'medium',
    topicFocus: '',
    questionTypes: ['multiple-choice'],
    timeLimit: 30,
    randomizeQuestions: true,
    showCorrectAnswers: true,
    allowRetakes: false,
    ...parameters
  });

  const difficultyOptions = [
    { value: 'easy', label: 'Easy', description: 'Basic concepts and definitions' },
    { value: 'medium', label: 'Medium', description: 'Application and analysis' },
    { value: 'hard', label: 'Hard', description: 'Complex problem solving' },
    { value: 'mixed', label: 'Mixed', description: 'Combination of all levels' }
  ];

  const questionTypeOptions = [
    { value: 'multiple-choice', label: 'Multiple Choice' },
    { value: 'true-false', label: 'True/False' },
    { value: 'fill-blanks', label: 'Fill in the Blanks' },
    { value: 'short-answer', label: 'Short Answer' }
  ];

  const timeLimitOptions = [
    { value: 15, label: '15 minutes' },
    { value: 30, label: '30 minutes' },
    { value: 45, label: '45 minutes' },
    { value: 60, label: '1 hour' },
    { value: 90, label: '1.5 hours' },
    { value: 120, label: '2 hours' },
    { value: 0, label: 'No time limit' }
  ];

  const handleParameterChange = (key, value) => {
    const updatedParameters = { ...localParameters, [key]: value };
    setLocalParameters(updatedParameters);
    onParametersChange(updatedParameters);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-2">Quiz Parameters</h3>
        <p className="text-sm text-muted-foreground">
          Configure your quiz settings to customize the generated questions.
        </p>
      </div>
      <div className="space-y-6">
        {/* Basic Settings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Number of Questions"
            type="number"
            min="5"
            max="50"
            value={localParameters?.questionCount}
            onChange={(e) => handleParameterChange('questionCount', parseInt(e?.target?.value))}
            disabled={disabled}
            description="Choose between 5-50 questions"
          />

          <Select
            label="Difficulty Level"
            options={difficultyOptions}
            value={localParameters?.difficulty}
            onChange={(value) => handleParameterChange('difficulty', value)}
            disabled={disabled}
          />
        </div>

        {/* Topic Focus */}
        <Input
          label="Topic Focus (Optional)"
          type="text"
          placeholder="e.g., Chapter 5: Photosynthesis, World War II, Calculus Derivatives"
          value={localParameters?.topicFocus}
          onChange={(e) => handleParameterChange('topicFocus', e?.target?.value)}
          disabled={disabled}
          description="Specify particular topics or chapters to focus on"
        />

        {/* Question Types */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-3">
            Question Types
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {questionTypeOptions?.map((type) => (
              <Checkbox
                key={type?.value}
                label={type?.label}
                checked={localParameters?.questionTypes?.includes(type?.value)}
                onChange={(e) => {
                  const updatedTypes = e?.target?.checked
                    ? [...localParameters?.questionTypes, type?.value]
                    : localParameters?.questionTypes?.filter(t => t !== type?.value);
                  handleParameterChange('questionTypes', updatedTypes);
                }}
                disabled={disabled}
              />
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Select at least one question type
          </p>
        </div>

        {/* Advanced Settings */}
        <div className="border-t border-border pt-6">
          <h4 className="text-sm font-semibold text-foreground mb-4">Advanced Settings</h4>
          
          <div className="space-y-4">
            <Select
              label="Time Limit"
              options={timeLimitOptions}
              value={localParameters?.timeLimit}
              onChange={(value) => handleParameterChange('timeLimit', value)}
              disabled={disabled}
              description="Set a time limit for quiz completion"
            />

            <div className="space-y-3">
              <Checkbox
                label="Randomize Question Order"
                description="Questions will appear in random order for each attempt"
                checked={localParameters?.randomizeQuestions}
                onChange={(e) => handleParameterChange('randomizeQuestions', e?.target?.checked)}
                disabled={disabled}
              />

              <Checkbox
                label="Show Correct Answers After Completion"
                description="Students can review correct answers after submitting"
                checked={localParameters?.showCorrectAnswers}
                onChange={(e) => handleParameterChange('showCorrectAnswers', e?.target?.checked)}
                disabled={disabled}
              />

              <Checkbox
                label="Allow Multiple Attempts"
                description="Students can retake the quiz multiple times"
                checked={localParameters?.allowRetakes}
                onChange={(e) => handleParameterChange('allowRetakes', e?.target?.checked)}
                disabled={disabled}
              />
            </div>
          </div>
        </div>

        {/* Premium Features Notice */}
        <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <div className="w-5 h-5 bg-accent rounded-full flex items-center justify-center mt-0.5">
              <span className="text-xs text-white font-bold">P</span>
            </div>
            <div>
              <h5 className="text-sm font-medium text-foreground mb-1">Premium Features</h5>
              <p className="text-xs text-muted-foreground">
                Advanced question types, custom formatting, and detailed analytics are available with QuizCraft Premium.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizParametersForm;