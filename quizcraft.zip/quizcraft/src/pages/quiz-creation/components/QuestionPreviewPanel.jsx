import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const QuestionPreviewPanel = ({ 
  questions = [], 
  onQuestionUpdate, 
  onQuestionDelete, 
  onBulkAction 
}) => {
  const [selectedQuestions, setSelectedQuestions] = useState([]);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDifficulty, setFilterDifficulty] = useState('all');

  // Mock questions data
  const mockQuestions = [
    {
      id: 1,
      question: "What is the primary function of chlorophyll in photosynthesis?",
      options: [
        "To absorb light energy",
        "To store glucose",
        "To release oxygen",
        "To transport water"
      ],
      correctAnswer: 0,
      difficulty: "medium",
      topic: "Photosynthesis",
      type: "multiple-choice"
    },
    {
      id: 2,
      question: "Which of the following is NOT a product of photosynthesis?",
      options: [
        "Glucose",
        "Oxygen",
        "Carbon dioxide",
        "Water"
      ],
      correctAnswer: 2,
      difficulty: "easy",
      topic: "Photosynthesis",
      type: "multiple-choice"
    },
    {
      id: 3,
      question: "The light-dependent reactions of photosynthesis occur in which part of the chloroplast?",
      options: [
        "Stroma",
        "Thylakoid membrane",
        "Outer membrane",
        "Intermembrane space"
      ],
      correctAnswer: 1,
      difficulty: "hard",
      topic: "Photosynthesis",
      type: "multiple-choice"
    }
  ];

  const displayQuestions = questions?.length > 0 ? questions : mockQuestions;

  const filteredQuestions = displayQuestions?.filter(question => {
    const matchesSearch = question?.question?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         question?.topic?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesDifficulty = filterDifficulty === 'all' || question?.difficulty === filterDifficulty;
    return matchesSearch && matchesDifficulty;
  });

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedQuestions(filteredQuestions?.map(q => q?.id));
    } else {
      setSelectedQuestions([]);
    }
  };

  const handleSelectQuestion = (questionId, checked) => {
    if (checked) {
      setSelectedQuestions(prev => [...prev, questionId]);
    } else {
      setSelectedQuestions(prev => prev?.filter(id => id !== questionId));
    }
  };

  const handleEditQuestion = (question) => {
    setEditingQuestion({ ...question });
  };

  const handleSaveEdit = () => {
    onQuestionUpdate(editingQuestion);
    setEditingQuestion(null);
  };

  const handleCancelEdit = () => {
    setEditingQuestion(null);
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'text-success bg-success/10';
      case 'medium': return 'text-warning bg-warning/10';
      case 'hard': return 'text-error bg-error/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  if (displayQuestions?.length === 0) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="FileQuestion" size={32} className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">No Questions Generated Yet</h3>
          <p className="text-sm text-muted-foreground">
            Upload your content and configure quiz parameters to generate questions.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Generated Questions</h3>
            <p className="text-sm text-muted-foreground">
              {filteredQuestions?.length} questions ready for review
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              iconName="Eye"
              iconPosition="left"
            >
              Preview Quiz
            </Button>
            <Button
              variant="default"
              size="sm"
              iconName="Save"
              iconPosition="left"
            >
              Save Quiz
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <Input
              type="search"
              placeholder="Search questions or topics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e?.target?.value)}
              className="w-full"
            />
          </div>
          
          <select
            value={filterDifficulty}
            onChange={(e) => setFilterDifficulty(e?.target?.value)}
            className="px-3 py-2 border border-border rounded-md bg-input text-foreground text-sm"
          >
            <option value="all">All Difficulties</option>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </div>

        {/* Bulk Actions */}
        {selectedQuestions?.length > 0 && (
          <div className="mt-4 p-3 bg-muted rounded-lg flex items-center justify-between">
            <span className="text-sm text-foreground">
              {selectedQuestions?.length} question(s) selected
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                iconName="Trash2"
                onClick={() => onBulkAction('delete', selectedQuestions)}
              >
                Delete Selected
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="Copy"
                onClick={() => onBulkAction('duplicate', selectedQuestions)}
              >
                Duplicate
              </Button>
            </div>
          </div>
        )}
      </div>
      {/* Questions List */}
      <div className="max-h-96 overflow-y-auto">
        {/* Select All */}
        <div className="sticky top-0 bg-card border-b border-border p-4">
          <Checkbox
            label={`Select all ${filteredQuestions?.length} questions`}
            checked={selectedQuestions?.length === filteredQuestions?.length && filteredQuestions?.length > 0}
            onChange={(e) => handleSelectAll(e?.target?.checked)}
          />
        </div>

        {/* Question Cards */}
        <div className="p-4 space-y-4">
          {filteredQuestions?.map((question, index) => (
            <div
              key={question?.id}
              className={`border border-border rounded-lg p-4 transition-colors duration-200 ${
                selectedQuestions?.includes(question?.id) ? 'bg-primary/5 border-primary/20' : 'bg-card'
              }`}
            >
              {editingQuestion?.id === question?.id ? (
                // Edit Mode
                (<div className="space-y-4">
                  <Input
                    label="Question"
                    value={editingQuestion?.question}
                    onChange={(e) => setEditingQuestion(prev => ({ ...prev, question: e?.target?.value }))}
                    className="w-full"
                  />
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Answer Options</label>
                    <div className="space-y-2">
                      {editingQuestion?.options?.map((option, optionIndex) => (
                        <div key={optionIndex} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            name={`correct-${editingQuestion?.id}`}
                            checked={editingQuestion?.correctAnswer === optionIndex}
                            onChange={() => setEditingQuestion(prev => ({ ...prev, correctAnswer: optionIndex }))}
                            className="text-primary"
                          />
                          <Input
                            value={option}
                            onChange={(e) => {
                              const newOptions = [...editingQuestion?.options];
                              newOptions[optionIndex] = e?.target?.value;
                              setEditingQuestion(prev => ({ ...prev, options: newOptions }));
                            }}
                            className="flex-1"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center justify-end space-x-2">
                    <Button variant="outline" size="sm" onClick={handleCancelEdit}>
                      Cancel
                    </Button>
                    <Button variant="default" size="sm" onClick={handleSaveEdit}>
                      Save Changes
                    </Button>
                  </div>
                </div>)
              ) : (
                // View Mode
                (<div>
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      checked={selectedQuestions?.includes(question?.id)}
                      onChange={(e) => handleSelectQuestion(question?.id, e?.target?.checked)}
                      className="mt-1"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-sm font-medium text-muted-foreground">
                              Question {index + 1}
                            </span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(question?.difficulty)}`}>
                              {question?.difficulty}
                            </span>
                            <span className="px-2 py-1 bg-muted rounded-full text-xs text-muted-foreground">
                              {question?.topic}
                            </span>
                          </div>
                          <h4 className="text-base font-medium text-foreground mb-3">
                            {question?.question}
                          </h4>
                        </div>
                        
                        <div className="flex items-center space-x-1 ml-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            iconName="Edit"
                            onClick={() => handleEditQuestion(question)}
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            iconName="Trash2"
                            onClick={() => onQuestionDelete(question?.id)}
                            className="text-error hover:text-error"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        {question?.options?.map((option, optionIndex) => (
                          <div
                            key={optionIndex}
                            className={`flex items-center space-x-2 p-2 rounded-md ${
                              optionIndex === question?.correctAnswer
                                ? 'bg-success/10 border border-success/20' :'bg-muted/50'
                            }`}
                          >
                            <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                              optionIndex === question?.correctAnswer
                                ? 'border-success bg-success' :'border-muted-foreground'
                            }`}>
                              {optionIndex === question?.correctAnswer && (
                                <Icon name="Check" size={10} className="text-white" />
                              )}
                            </div>
                            <span className={`text-sm ${
                              optionIndex === question?.correctAnswer
                                ? 'text-success font-medium' :'text-foreground'
                            }`}>
                              {option}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>)
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuestionPreviewPanel;