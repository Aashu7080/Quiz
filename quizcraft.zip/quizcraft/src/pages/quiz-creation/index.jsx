import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import PageHeader from '../../components/ui/PageHeader';
import FileUploadArea from './components/FileUploadArea';
import QuizParametersForm from './components/QuizParametersForm';
import AIProcessingStatus from './components/AIProcessingStatus';
import QuestionPreviewPanel from './components/QuestionPreviewPanel';
import QuizSaveOptions from './components/QuizSaveOptions';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const QuizCreation = () => {
  const navigate = useNavigate();
  const [currentUser] = useState({
    id: 1,
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@university.edu",
    role: "teacher"
  });

  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [quizParameters, setQuizParameters] = useState({
    questionCount: 10,
    difficulty: 'medium',
    topicFocus: '',
    questionTypes: ['multiple-choice'],
    timeLimit: 30,
    randomizeQuestions: true,
    showCorrectAnswers: true,
    allowRetakes: false
  });

  const [processingState, setProcessingState] = useState({
    isProcessing: false,
    progress: 0,
    currentStep: '',
    estimatedTime: 0,
    error: null
  });

  const [generatedQuestions, setGeneratedQuestions] = useState([]);
  const [activeStep, setActiveStep] = useState(1);

  const steps = [
    { id: 1, title: 'Upload Content', icon: 'Upload' },
    { id: 2, title: 'Configure Quiz', icon: 'Settings' },
    { id: 3, title: 'AI Processing', icon: 'Brain' },
    { id: 4, title: 'Review Questions', icon: 'FileQuestion' },
    { id: 5, title: 'Save & Share', icon: 'Share' }
  ];

  const breadcrumbs = [
    { label: 'Dashboard', onClick: () => navigate('/teacher-dashboard') },
    { label: 'Quiz Creation' }
  ];

  const handleFileUpload = (files) => {
    setUploadedFiles(files);
    setActiveStep(2);
  };

  const handleParametersChange = (parameters) => {
    setQuizParameters(parameters);
  };

  const handleGenerateQuiz = () => {
    if (uploadedFiles?.length === 0) {
      alert('Please upload at least one file before generating the quiz.');
      return;
    }

    setActiveStep(3);
    setProcessingState({
      isProcessing: true,
      progress: 0,
      currentStep: 'upload',
      estimatedTime: 120,
      error: null
    });

    // Simulate AI processing
    const processingSteps = ['upload', 'analyze', 'extract', 'generate', 'review'];
    let currentStepIndex = 0;
    let progress = 0;

    const interval = setInterval(() => {
      progress += Math.random() * 15 + 5;
      
      if (progress >= 100) {
        progress = 100;
        setProcessingState(prev => ({
          ...prev,
          progress: 100,
          currentStep: 'review',
          isProcessing: false,
          estimatedTime: 0
        }));
        setActiveStep(4);
        clearInterval(interval);
        return;
      }

      const stepIndex = Math.floor((progress / 100) * processingSteps?.length);
      if (stepIndex !== currentStepIndex && stepIndex < processingSteps?.length) {
        currentStepIndex = stepIndex;
      }

      setProcessingState(prev => ({
        ...prev,
        progress,
        currentStep: processingSteps?.[currentStepIndex],
        estimatedTime: Math.max(0, prev?.estimatedTime - 5)
      }));
    }, 1000);
  };

  const handleQuestionUpdate = (updatedQuestion) => {
    setGeneratedQuestions(prev => 
      prev?.map(q => q?.id === updatedQuestion?.id ? updatedQuestion : q)
    );
  };

  const handleQuestionDelete = (questionId) => {
    setGeneratedQuestions(prev => prev?.filter(q => q?.id !== questionId));
  };

  const handleBulkAction = (action, questionIds) => {
    if (action === 'delete') {
      setGeneratedQuestions(prev => prev?.filter(q => !questionIds?.includes(q?.id)));
    } else if (action === 'duplicate') {
      const questionsToClone = generatedQuestions?.filter(q => questionIds?.includes(q?.id));
      const clonedQuestions = questionsToClone?.map(q => ({
        ...q,
        id: Date.now() + Math.random(),
        question: `${q?.question} (Copy)`
      }));
      setGeneratedQuestions(prev => [...prev, ...clonedQuestions]);
    }
  };

  const handleSaveQuiz = (quizData) => {
    console.log('Saving quiz:', quizData);
    alert('Quiz saved successfully!');
    navigate('/teacher-dashboard');
  };

  const handleShareQuiz = (quizData) => {
    console.log('Sharing quiz:', quizData);
    alert('Quiz saved and shared successfully!');
    navigate('/teacher-dashboard');
  };

  const canProceedToNextStep = () => {
    switch (activeStep) {
      case 1: return uploadedFiles?.length > 0;
      case 2: return quizParameters?.questionCount > 0;
      case 3: return !processingState?.isProcessing;
      case 4: return generatedQuestions?.length > 0;
      default: return true;
    }
  };

  const getStepContent = () => {
    switch (activeStep) {
      case 1:
        return (
          <FileUploadArea
            onFileUpload={handleFileUpload}
            isProcessing={processingState?.isProcessing}
          />
        );
      case 2:
        return (
          <QuizParametersForm
            parameters={quizParameters}
            onParametersChange={handleParametersChange}
            disabled={processingState?.isProcessing}
          />
        );
      case 3:
        return (
          <AIProcessingStatus
            isProcessing={processingState?.isProcessing}
            progress={processingState?.progress}
            currentStep={processingState?.currentStep}
            estimatedTime={processingState?.estimatedTime}
            error={processingState?.error}
          />
        );
      case 4:
        return (
          <QuestionPreviewPanel
            questions={generatedQuestions}
            onQuestionUpdate={handleQuestionUpdate}
            onQuestionDelete={handleQuestionDelete}
            onBulkAction={handleBulkAction}
          />
        );
      case 5:
        return (
          <QuizSaveOptions
            onSaveQuiz={handleSaveQuiz}
            onShareQuiz={handleShareQuiz}
            isLoading={false}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        user={currentUser}
        currentPath="/quiz-creation"
        onNavigate={navigate}
      />
      <main className="pt-16">
        <PageHeader
          title="Create New Quiz"
          subtitle="Generate quiz questions automatically from your educational content using AI"
          breadcrumbs={breadcrumbs}
          actions={[
            <Button
              key="help"
              variant="outline"
              iconName="HelpCircle"
              iconPosition="left"
            >
              Help Guide
            </Button>
          ]}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {steps?.map((step, index) => (
                <React.Fragment key={step?.id}>
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors duration-200 ${
                        activeStep === step?.id
                          ? 'bg-primary border-primary text-white'
                          : activeStep > step?.id
                          ? 'bg-success border-success text-white' :'bg-card border-border text-muted-foreground'
                      }`}
                    >
                      {activeStep > step?.id ? (
                        <Icon name="Check" size={16} />
                      ) : (
                        <Icon name={step?.icon} size={16} />
                      )}
                    </div>
                    <div className="mt-2 text-center">
                      <p className={`text-xs font-medium ${
                        activeStep >= step?.id ? 'text-foreground' : 'text-muted-foreground'
                      }`}>
                        {step?.title}
                      </p>
                    </div>
                  </div>
                  
                  {index < steps?.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-4 transition-colors duration-200 ${
                        activeStep > step?.id ? 'bg-success' : 'bg-border'
                      }`}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Primary Content */}
            <div className="lg:col-span-2">
              {getStepContent()}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  {activeStep === 2 && (
                    <Button
                      variant="default"
                      fullWidth
                      onClick={handleGenerateQuiz}
                      disabled={!canProceedToNextStep()}
                      iconName="Zap"
                      iconPosition="left"
                    >
                      Generate Quiz
                    </Button>
                  )}
                  
                  {activeStep === 4 && (
                    <Button
                      variant="default"
                      fullWidth
                      onClick={() => setActiveStep(5)}
                      disabled={!canProceedToNextStep()}
                      iconName="ArrowRight"
                      iconPosition="right"
                    >
                      Continue to Save
                    </Button>
                  )}

                  <Button
                    variant="outline"
                    fullWidth
                    onClick={() => navigate('/teacher-dashboard')}
                    iconName="ArrowLeft"
                    iconPosition="left"
                  >
                    Back to Dashboard
                  </Button>
                </div>
              </div>

              {/* Tips & Guidelines */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Tips for Better Results</h3>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <div className="flex items-start space-x-2">
                    <Icon name="Lightbulb" size={16} className="text-warning mt-0.5" />
                    <p>Upload well-structured documents with clear headings and sections</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Target" size={16} className="text-primary mt-0.5" />
                    <p>Specify topic focus for more targeted question generation</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Clock" size={16} className="text-success mt-0.5" />
                    <p>Processing time depends on document length and complexity</p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Edit" size={16} className="text-accent mt-0.5" />
                    <p>Review and edit generated questions before sharing</p>
                  </div>
                </div>
              </div>

              {/* Current Progress */}
              {uploadedFiles?.length > 0 && (
                <div className="bg-card rounded-lg border border-border p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-4">Current Session</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Files uploaded:</span>
                      <span className="font-medium text-foreground">{uploadedFiles?.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Questions to generate:</span>
                      <span className="font-medium text-foreground">{quizParameters?.questionCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Difficulty level:</span>
                      <span className="font-medium text-foreground capitalize">{quizParameters?.difficulty}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time limit:</span>
                      <span className="font-medium text-foreground">
                        {quizParameters?.timeLimit === 0 ? 'No limit' : `${quizParameters?.timeLimit} min`}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default QuizCreation;