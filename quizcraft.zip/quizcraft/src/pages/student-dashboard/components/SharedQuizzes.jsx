import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SharedQuizzes = ({ sharedQuizzes, onStartQuiz, onViewQuiz }) => {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Icon name="Share2" size={20} className="text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Shared with You</h2>
        </div>
        <span className="text-sm text-muted-foreground">{sharedQuizzes?.length} quizzes</span>
      </div>
      <div className="space-y-4">
        {sharedQuizzes?.map((quiz) => (
          <div key={quiz?.id} className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors duration-200">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className="font-medium text-foreground mb-2">{quiz?.title}</h3>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-2">
                  <div className="flex items-center space-x-1">
                    <Icon name="FileText" size={14} />
                    <span>{quiz?.questionCount} questions</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={14} />
                    <span>{quiz?.duration} min</span>
                  </div>
                  {quiz?.subject && (
                    <div className="flex items-center space-x-1">
                      <Icon name="BookOpen" size={14} />
                      <span>{quiz?.subject}</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-primary-foreground">
                      {quiz?.sharedBy?.charAt(0)?.toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{quiz?.sharedBy}</p>
                    <p className="text-xs text-muted-foreground">Shared {quiz?.sharedDate}</p>
                  </div>
                </div>
              </div>
              {quiz?.difficulty && (
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  quiz?.difficulty === 'Easy' ? 'bg-success/10 text-success' :
                  quiz?.difficulty === 'Medium'? 'bg-warning/10 text-warning' : 'bg-error/10 text-error'
                }`}>
                  {quiz?.difficulty}
                </span>
              )}
            </div>

            {quiz?.attempts > 0 && (
              <div className="mb-3 p-2 bg-muted rounded-md">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Your best score:</span>
                  <span className={`font-medium ${
                    quiz?.bestScore >= 80 ? 'text-success' :
                    quiz?.bestScore >= 60 ? 'text-warning' : 'text-error'
                  }`}>
                    {quiz?.bestScore}%
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {quiz?.attempts} attempt{quiz?.attempts !== 1 ? 's' : ''}
                </p>
              </div>
            )}

            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                iconName="Eye"
                iconPosition="left"
                onClick={() => onViewQuiz(quiz?.id)}
                className="flex-1"
              >
                Preview
              </Button>
              <Button
                variant="default"
                size="sm"
                iconName="Play"
                iconPosition="left"
                onClick={() => onStartQuiz(quiz?.id)}
                className="flex-1"
              >
                {quiz?.attempts > 0 ? 'Retake' : 'Start'}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SharedQuizzes;