import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const QuizSearch = ({ onSearch, onFilter, onClearFilters }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [selectedSort, setSelectedSort] = useState('recent');

  const subjectOptions = [
    { value: '', label: 'All Subjects' },
    { value: 'mathematics', label: 'Mathematics' },
    { value: 'science', label: 'Science' },
    { value: 'history', label: 'History' },
    { value: 'english', label: 'English' },
    { value: 'geography', label: 'Geography' },
    { value: 'computer-science', label: 'Computer Science' }
  ];

  const difficultyOptions = [
    { value: '', label: 'All Levels' },
    { value: 'easy', label: 'Easy' },
    { value: 'medium', label: 'Medium' },
    { value: 'hard', label: 'Hard' }
  ];

  const sortOptions = [
    { value: 'recent', label: 'Most Recent' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'name', label: 'Name A-Z' },
    { value: 'score', label: 'Best Score' },
    { value: 'attempts', label: 'Most Attempts' }
  ];

  const handleSearch = (e) => {
    const query = e?.target?.value;
    setSearchQuery(query);
    onSearch(query);
  };

  const handleFilterChange = () => {
    onFilter({
      subject: selectedSubject,
      difficulty: selectedDifficulty,
      sort: selectedSort
    });
  };

  const handleClearAll = () => {
    setSearchQuery('');
    setSelectedSubject('');
    setSelectedDifficulty('');
    setSelectedSort('recent');
    onClearFilters();
  };

  React.useEffect(() => {
    handleFilterChange();
  }, [selectedSubject, selectedDifficulty, selectedSort]);

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Search" size={20} className="text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Find Your Quizzes</h2>
      </div>
      <div className="space-y-4">
        {/* Search Input */}
        <div>
          <Input
            type="search"
            placeholder="Search quizzes by title, subject, or content..."
            value={searchQuery}
            onChange={handleSearch}
            className="w-full"
          />
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Select
            label="Subject"
            options={subjectOptions}
            value={selectedSubject}
            onChange={setSelectedSubject}
          />
          
          <Select
            label="Difficulty"
            options={difficultyOptions}
            value={selectedDifficulty}
            onChange={setSelectedDifficulty}
          />
          
          <Select
            label="Sort by"
            options={sortOptions}
            value={selectedSort}
            onChange={setSelectedSort}
          />

          <div className="flex items-end">
            <Button
              variant="outline"
              size="default"
              iconName="X"
              iconPosition="left"
              onClick={handleClearAll}
              fullWidth
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Active Filters Display */}
        {(selectedSubject || selectedDifficulty || searchQuery) && (
          <div className="flex items-center space-x-2 pt-2 border-t border-border">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            <div className="flex items-center space-x-2">
              {searchQuery && (
                <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                  Search: "{searchQuery}"
                </span>
              )}
              {selectedSubject && (
                <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">
                  {subjectOptions?.find(opt => opt?.value === selectedSubject)?.label}
                </span>
              )}
              {selectedDifficulty && (
                <span className="px-2 py-1 bg-warning/10 text-warning text-xs rounded-full">
                  {difficultyOptions?.find(opt => opt?.value === selectedDifficulty)?.label}
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizSearch;