import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PremiumFeatures = ({ onUpgrade }) => {
  const premiumFeatures = [
    {
      icon: 'BarChart3',
      title: 'Advanced Analytics',
      description: 'Detailed performance insights and learning patterns',
      color: 'text-accent'
    },
    {
      icon: 'FileDown',
      title: 'PDF Export',
      description: 'Export quizzes and results as professional PDFs',
      color: 'text-success'
    },
    {
      icon: 'Zap',
      title: 'AI-Powered Insights',
      description: 'Personalized study recommendations and weak area analysis',
      color: 'text-warning'
    },
    {
      icon: 'Users',
      title: 'Collaboration Tools',
      description: 'Create study groups and share progress with classmates',
      color: 'text-primary'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/20 rounded-lg p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Crown" size={20} className="text-warning" />
        <h2 className="text-lg font-semibold text-foreground">Unlock Premium Features</h2>
      </div>
      <p className="text-muted-foreground mb-6">
        Enhance your learning experience with advanced tools and insights.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        {premiumFeatures?.map((feature, index) => (
          <div key={index} className="flex items-start space-x-3">
            <div className="p-2 bg-card rounded-lg border border-border">
              <Icon name={feature?.icon} size={16} className={feature?.color} />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-medium text-foreground mb-1">{feature?.title}</h3>
              <p className="text-xs text-muted-foreground">{feature?.description}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between p-4 bg-card rounded-lg border border-border">
        <div>
          <p className="text-sm font-medium text-foreground">Premium Plan</p>
          <p className="text-xs text-muted-foreground">Starting at $9.99/month</p>
        </div>
        <Button
          variant="default"
          size="sm"
          iconName="ArrowRight"
          iconPosition="right"
          onClick={onUpgrade}
        >
          Upgrade Now
        </Button>
      </div>
    </div>
  );
};

export default PremiumFeatures;