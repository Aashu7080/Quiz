import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuizCard = ({ quiz, onAttempt, onRetry, onView }) => {
  const getScoreColor = (score) => {
    if (score >= 80) return 'text-success';
    if (score >= 60) return 'text-warning';
    return 'text-error';
  };

  const getScoreBgColor = (score) => {
    if (score >= 80) return 'bg-success/10';
    if (score >= 60) return 'bg-warning/10';
    return 'bg-error/10';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 hover:shadow-moderate transition-shadow duration-200">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-foreground mb-2">{quiz?.title}</h3>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="FileText" size={16} />
              <span>{quiz?.questionCount} questions</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={16} />
              <span>{quiz?.duration} min</span>
            </div>
            {quiz?.subject && (
              <div className="flex items-center space-x-1">
                <Icon name="BookOpen" size={16} />
                <span>{quiz?.subject}</span>
              </div>
            )}
          </div>
        </div>
        {quiz?.difficulty && (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            quiz?.difficulty === 'Easy' ? 'bg-success/10 text-success' :
            quiz?.difficulty === 'Medium'? 'bg-warning/10 text-warning' : 'bg-error/10 text-error'
          }`}>
            {quiz?.difficulty}
          </span>
        )}
      </div>
      {quiz?.lastAttempt && (
        <div className="mb-4 p-3 bg-muted rounded-md">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Last attempt:</span>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${getScoreBgColor(quiz?.lastAttempt?.score)} ${getScoreColor(quiz?.lastAttempt?.score)}`}>
              {quiz?.lastAttempt?.score}%
            </div>
          </div>
          <div className="flex items-center justify-between mt-1">
            <span className="text-xs text-muted-foreground">{quiz?.lastAttempt?.date}</span>
            <span className="text-xs text-muted-foreground">
              {quiz?.lastAttempt?.correctAnswers}/{quiz?.questionCount} correct
            </span>
          </div>
        </div>
      )}
      {quiz?.sharedBy && (
        <div className="mb-4 flex items-center space-x-2 text-sm text-muted-foreground">
          <Icon name="Share2" size={16} />
          <span>Shared by {quiz?.sharedBy}</span>
        </div>
      )}
      <div className="flex items-center space-x-2">
        {quiz?.lastAttempt ? (
          <>
            <Button
              variant="outline"
              size="sm"
              iconName="Eye"
              iconPosition="left"
              onClick={() => onView(quiz?.id)}
              className="flex-1"
            >
              View Results
            </Button>
            <Button
              variant="default"
              size="sm"
              iconName="RotateCcw"
              iconPosition="left"
              onClick={() => onRetry(quiz?.id)}
              className="flex-1"
            >
              Retry Quiz
            </Button>
          </>
        ) : (
          <Button
            variant="default"
            size="sm"
            iconName="Play"
            iconPosition="left"
            onClick={() => onAttempt(quiz?.id)}
            fullWidth
          >
            Start Quiz
          </Button>
        )}
      </div>
    </div>
  );
};

export default QuizCard;