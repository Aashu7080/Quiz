import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RecentAttempts = ({ attempts, onViewDetails, onRetakeQuiz }) => {
  const getScoreColor = (score) => {
    if (score >= 80) return 'text-success';
    if (score >= 60) return 'text-warning';
    return 'text-error';
  };

  const getScoreBgColor = (score) => {
    if (score >= 80) return 'bg-success/10';
    if (score >= 60) return 'bg-warning/10';
    return 'bg-error/10';
  };

  const getImprovementSuggestion = (score) => {
    if (score >= 80) return "Excellent work! Keep it up!";
    if (score >= 60) return "Good progress! Review missed topics.";
    return "Focus on fundamentals and retry.";
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Icon name="History" size={20} className="text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Recent Attempts</h2>
        </div>
        <Button variant="ghost" size="sm" iconName="ExternalLink">
          View All
        </Button>
      </div>
      <div className="space-y-4">
        {attempts?.map((attempt) => (
          <div key={attempt?.id} className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors duration-200">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className="font-medium text-foreground mb-1">{attempt?.quizTitle}</h3>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <span>{attempt?.date}</span>
                  <span>{attempt?.duration}</span>
                  <span>{attempt?.correctAnswers}/{attempt?.totalQuestions} correct</span>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${getScoreBgColor(attempt?.score)} ${getScoreColor(attempt?.score)}`}>
                {attempt?.score}%
              </div>
            </div>

            <div className="mb-3">
              <p className="text-sm text-muted-foreground mb-1">Performance:</p>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className={`rounded-full h-2 transition-all duration-300 ${
                    attempt?.score >= 80 ? 'bg-success' :
                    attempt?.score >= 60 ? 'bg-warning' : 'bg-error'
                  }`}
                  style={{ width: `${attempt?.score}%` }}
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground italic">
                {getImprovementSuggestion(attempt?.score)}
              </p>
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  iconName="Eye"
                  onClick={() => onViewDetails(attempt?.id)}
                >
                  Details
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="RotateCcw"
                  onClick={() => onRetakeQuiz(attempt?.quizId)}
                >
                  Retake
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentAttempts;