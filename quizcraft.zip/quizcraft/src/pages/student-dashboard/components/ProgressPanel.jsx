import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressPanel = ({ stats }) => {
  const progressItems = [
    {
      label: 'Quizzes Completed',
      value: stats?.completedQuizzes,
      total: stats?.totalQuizzes,
      icon: 'CheckCircle',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      label: 'Average Score',
      value: `${stats?.averageScore}%`,
      icon: 'Target',
      color: stats?.averageScore >= 80 ? 'text-success' : stats?.averageScore >= 60 ? 'text-warning' : 'text-error',
      bgColor: stats?.averageScore >= 80 ? 'bg-success/10' : stats?.averageScore >= 60 ? 'bg-warning/10' : 'bg-error/10'
    },
    {
      label: 'Learning Streak',
      value: `${stats?.streak} days`,
      icon: 'Flame',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      label: 'Time Studied',
      value: `${stats?.timeStudied}h`,
      icon: 'Clock',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Icon name="TrendingUp" size={20} className="text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Learning Progress</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        {progressItems?.map((item, index) => (
          <div key={index} className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${item?.bgColor}`}>
              <Icon name={item?.icon} size={20} className={item?.color} />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{item?.label}</p>
              <p className="text-lg font-semibold text-foreground">
                {item?.total ? `${item?.value}/${item?.total}` : item?.value}
              </p>
            </div>
          </div>
        ))}
      </div>
      {/* Progress Bar for Quiz Completion */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Quiz Completion</span>
          <span className="text-sm font-medium text-foreground">
            {Math.round((stats?.completedQuizzes / stats?.totalQuizzes) * 100)}%
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className="bg-primary rounded-full h-2 transition-all duration-300"
            style={{ width: `${(stats?.completedQuizzes / stats?.totalQuizzes) * 100}%` }}
          />
        </div>
      </div>
      {/* Weekly Goal */}
      <div className="p-3 bg-muted rounded-md">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Weekly Goal</span>
          <span className="text-xs text-muted-foreground">{stats?.weeklyProgress}/5 quizzes</span>
        </div>
        <div className="w-full bg-background rounded-full h-1.5">
          <div
            className="bg-accent rounded-full h-1.5 transition-all duration-300"
            style={{ width: `${(stats?.weeklyProgress / 5) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default ProgressPanel;