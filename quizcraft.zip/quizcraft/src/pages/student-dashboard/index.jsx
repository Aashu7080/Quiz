import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import PageHeader from '../../components/ui/PageHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import QuizCard from './components/QuizCard';
import ProgressPanel from './components/ProgressPanel';
import RecentAttempts from './components/RecentAttempts';
import SharedQuizzes from './components/SharedQuizzes';
import PremiumFeatures from './components/PremiumFeatures';
import QuizSearch from './components/QuizSearch';

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [filteredQuizzes, setFilteredQuizzes] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState({});

  // Mock user data
  const currentUser = {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    role: "student"
  };

  // Mock quiz data
  const myQuizzes = [
    {
      id: 1,
      title: "Advanced Calculus - Derivatives",
      questionCount: 15,
      duration: 20,
      subject: "Mathematics",
      difficulty: "Hard",
      lastAttempt: {
        score: 85,
        date: "2025-01-10",
        correctAnswers: 13
      },
      createdDate: "2025-01-08"
    },
    {
      id: 2,
      title: "World War II History",
      questionCount: 20,
      duration: 25,
      subject: "History",
      difficulty: "Medium",
      lastAttempt: {
        score: 72,
        date: "2025-01-09",
        correctAnswers: 14
      },
      createdDate: "2025-01-07"
    },
    {
      id: 3,
      title: "Organic Chemistry Basics",
      questionCount: 12,
      duration: 15,
      subject: "Science",
      difficulty: "Easy",
      createdDate: "2025-01-11"
    },
    {
      id: 4,
      title: "Shakespeare Literature Analysis",
      questionCount: 18,
      duration: 30,
      subject: "English",
      difficulty: "Medium",
      lastAttempt: {
        score: 91,
        date: "2025-01-12",
        correctAnswers: 16
      },
      createdDate: "2025-01-06"
    }
  ];

  // Mock shared quizzes data
  const sharedQuizzes = [
    {
      id: 5,
      title: "Physics - Newton\'s Laws",
      questionCount: 10,
      duration: 15,
      subject: "Science",
      difficulty: "Medium",
      sharedBy: "Dr. Michael Chen",
      sharedDate: "2 days ago",
      attempts: 2,
      bestScore: 88
    },
    {
      id: 6,
      title: "European Geography",
      questionCount: 25,
      duration: 20,
      subject: "Geography",
      difficulty: "Easy",
      sharedBy: "Prof. Lisa Anderson",
      sharedDate: "1 week ago",
      attempts: 0
    }
  ];

  // Mock progress stats
  const progressStats = {
    completedQuizzes: 8,
    totalQuizzes: 12,
    averageScore: 82,
    streak: 5,
    timeStudied: 24,
    weeklyProgress: 3
  };

  // Mock recent attempts
  const recentAttempts = [
    {
      id: 1,
      quizId: 4,
      quizTitle: "Shakespeare Literature Analysis",
      score: 91,
      date: "Jan 12, 2025",
      duration: "28 min",
      correctAnswers: 16,
      totalQuestions: 18
    },
    {
      id: 2,
      quizId: 1,
      quizTitle: "Advanced Calculus - Derivatives",
      score: 85,
      date: "Jan 10, 2025",
      duration: "18 min",
      correctAnswers: 13,
      totalQuestions: 15
    },
    {
      id: 3,
      quizId: 2,
      quizTitle: "World War II History",
      score: 72,
      date: "Jan 9, 2025",
      duration: "23 min",
      correctAnswers: 14,
      totalQuestions: 20
    }
  ];

  useEffect(() => {
    applyFilters();
  }, [searchQuery, activeFilters]);

  const applyFilters = () => {
    let filtered = [...myQuizzes];

    // Apply search filter
    if (searchQuery) {
      filtered = filtered?.filter(quiz =>
        quiz?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        quiz?.subject?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    // Apply subject filter
    if (activeFilters?.subject) {
      filtered = filtered?.filter(quiz =>
        quiz?.subject?.toLowerCase() === activeFilters?.subject?.toLowerCase()
      );
    }

    // Apply difficulty filter
    if (activeFilters?.difficulty) {
      filtered = filtered?.filter(quiz =>
        quiz?.difficulty?.toLowerCase() === activeFilters?.difficulty?.toLowerCase()
      );
    }

    // Apply sorting
    if (activeFilters?.sort) {
      switch (activeFilters?.sort) {
        case 'recent':
          filtered?.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));
          break;
        case 'oldest':
          filtered?.sort((a, b) => new Date(a.createdDate) - new Date(b.createdDate));
          break;
        case 'name':
          filtered?.sort((a, b) => a?.title?.localeCompare(b?.title));
          break;
        case 'score':
          filtered?.sort((a, b) => (b?.lastAttempt?.score || 0) - (a?.lastAttempt?.score || 0));
          break;
        default:
          break;
      }
    }

    setFilteredQuizzes(filtered);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const handleFilter = (filters) => {
    setActiveFilters(filters);
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setActiveFilters({});
  };

  const handleAttemptQuiz = (quizId) => {
    console.log('Starting quiz:', quizId);
    // Navigate to quiz taking interface
  };

  const handleRetryQuiz = (quizId) => {
    console.log('Retrying quiz:', quizId);
    // Navigate to quiz taking interface
  };

  const handleViewResults = (quizId) => {
    console.log('Viewing results for quiz:', quizId);
    // Navigate to quiz results page
  };

  const handleViewDetails = (attemptId) => {
    console.log('Viewing attempt details:', attemptId);
    // Navigate to detailed results page
  };

  const handleRetakeQuiz = (quizId) => {
    console.log('Retaking quiz:', quizId);
    // Navigate to quiz taking interface
  };

  const handleStartSharedQuiz = (quizId) => {
    console.log('Starting shared quiz:', quizId);
    // Navigate to quiz taking interface
  };

  const handleViewSharedQuiz = (quizId) => {
    console.log('Viewing shared quiz:', quizId);
    // Navigate to quiz preview
  };

  const handleUpgrade = () => {
    console.log('Upgrading to premium');
    // Navigate to subscription page
  };

  const handleNavigation = (path) => {
    navigate(path);
  };

  const breadcrumbs = [
    { label: 'Dashboard', href: '/student-dashboard' }
  ];

  const headerActions = [
    <Button
      key="create-quiz"
      variant="default"
      iconName="Plus"
      iconPosition="left"
      onClick={() => navigate('/quiz-creation')}
    >
      Create Quiz from Notes
    </Button>
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header
        user={currentUser}
        currentPath="/student-dashboard"
        onNavigate={handleNavigation}
      />
      <main className="pt-16">
        <PageHeader
          title="Student Dashboard"
          subtitle="Create quizzes from your study materials and track your learning progress"
          breadcrumbs={breadcrumbs}
          actions={headerActions}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Welcome Section */}
              <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-6 border border-primary/20">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <Icon name="BookOpen" size={24} color="white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">
                      Welcome back, {currentUser?.name}!
                    </h2>
                    <p className="text-muted-foreground">
                      Ready to continue your learning journey? You have {myQuizzes?.length - progressStats?.completedQuizzes} quizzes waiting.
                    </p>
                  </div>
                </div>
              </div>

              {/* Search and Filters */}
              <QuizSearch
                onSearch={handleSearch}
                onFilter={handleFilter}
                onClearFilters={handleClearFilters}
              />

              {/* My Quizzes Section */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-foreground">My Quizzes</h2>
                  <span className="text-sm text-muted-foreground">
                    {filteredQuizzes?.length} of {myQuizzes?.length} quizzes
                  </span>
                </div>

                {filteredQuizzes?.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredQuizzes?.map((quiz) => (
                      <QuizCard
                        key={quiz?.id}
                        quiz={quiz}
                        onAttempt={handleAttemptQuiz}
                        onRetry={handleRetryQuiz}
                        onView={handleViewResults}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-card border border-border rounded-lg">
                    <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">No quizzes found</h3>
                    <p className="text-muted-foreground mb-4">
                      {searchQuery || Object.keys(activeFilters)?.length > 0
                        ? "Try adjusting your search or filters" :"Create your first quiz from study notes"}
                    </p>
                    <Button
                      variant="default"
                      iconName="Plus"
                      iconPosition="left"
                      onClick={() => navigate('/quiz-creation')}
                    >
                      Create Quiz from Notes
                    </Button>
                  </div>
                )}
              </div>

              {/* Shared Quizzes Section */}
              <SharedQuizzes
                sharedQuizzes={sharedQuizzes}
                onStartQuiz={handleStartSharedQuiz}
                onViewQuiz={handleViewSharedQuiz}
              />

              {/* Recent Attempts */}
              <RecentAttempts
                attempts={recentAttempts}
                onViewDetails={handleViewDetails}
                onRetakeQuiz={handleRetakeQuiz}
              />
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Progress Panel */}
              <ProgressPanel stats={progressStats} />

              {/* Premium Features */}
              <PremiumFeatures onUpgrade={handleUpgrade} />

              {/* Quick Actions */}
              <div className="bg-card border border-border rounded-lg p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    fullWidth
                    iconName="Upload"
                    iconPosition="left"
                    onClick={() => navigate('/quiz-creation')}
                  >
                    Upload Study Notes
                  </Button>
                  <Button
                    variant="outline"
                    fullWidth
                    iconName="Settings"
                    iconPosition="left"
                    onClick={() => navigate('/account-settings')}
                  >
                    Account Settings
                  </Button>
                  <Button
                    variant="outline"
                    fullWidth
                    iconName="HelpCircle"
                    iconPosition="left"
                  >
                    Help & Support
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default StudentDashboard;