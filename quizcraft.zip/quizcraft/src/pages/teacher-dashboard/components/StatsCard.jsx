import React from 'react';
import Icon from '../../../components/AppIcon';

const StatsCard = ({
  title,
  value,
  change,
  changeType = 'neutral',
  icon,
  description,
  onClick
}) => {
  const getChangeColor = () => {
    switch (changeType) {
      case 'positive':
        return 'text-success bg-success/10';
      case 'negative':
        return 'text-error bg-error/10';
      default:
        return 'text-muted-foreground bg-muted/50';
    }
  };

  const getIconBgColor = () => {
    switch (changeType) {
      case 'positive':
        return 'bg-success/10 text-success';
      case 'negative':
        return 'bg-error/10 text-error';
      default:
        return 'bg-primary/10 text-primary';
    }
  };

  return (
    <div 
      className={`bg-card rounded-xl border border-border p-6 shadow-soft hover:shadow-medium transition-all duration-200 ${
        onClick ? 'cursor-pointer hover:border-primary/20 transform hover:scale-[1.02]' : ''
      } group`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getIconBgColor()} group-hover:scale-110 transition-transform duration-200`}>
          <Icon name={icon} size={20} />
        </div>
        {change && (
          <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${getChangeColor()}`}>
            {changeType === 'positive' && <Icon name="TrendingUp" size={12} className="mr-1" />}
            {changeType === 'negative' && <Icon name="TrendingDown" size={12} className="mr-1" />}
            {change}
          </span>
        )}
      </div>
      
      <div className="space-y-2">
        <div>
          <div className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors duration-200">
            {value}
          </div>
          <div className="text-sm font-medium text-muted-foreground">
            {title}
          </div>
        </div>
        
        {description && (
          <div className="text-xs text-muted-foreground leading-relaxed">
            {description}
          </div>
        )}
      </div>
    </div>
  );
};

export default StatsCard;