import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuizCard = ({ 
  quiz, 
  onEdit, 
  onShare, 
  onExport, 
  onView, 
  onDuplicate 
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const getStatusConfig = (status) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return {
          color: 'bg-success/10 text-success border-success/20',
          icon: 'CheckCircle',
          label: 'Active'
        };
      case 'draft':
        return {
          color: 'bg-warning/10 text-warning border-warning/20',
          icon: 'Clock',
          label: 'Draft'
        };
      case 'archived':
        return {
          color: 'bg-muted text-muted-foreground border-border',
          icon: 'Archive',
          label: 'Archived'
        };
      default:
        return {
          color: 'bg-muted text-muted-foreground border-border',
          icon: 'FileText',
          label: 'Unknown'
        };
    }
  };

  const statusConfig = getStatusConfig(quiz?.status);

  return (
    <div className="bg-card border border-border rounded-xl shadow-soft hover:shadow-medium transition-all duration-200 overflow-hidden group hover:border-primary/20 transform hover:scale-[1.01]">
      {/* Enhanced thumbnail with loading states */}
      <div className="relative h-48 bg-gradient-to-br from-muted/30 to-muted/50 overflow-hidden">
        {quiz?.thumbnail && !imageError && (
          <>
            {!imageLoaded && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Icon name="Loader2" size={24} className="animate-spin text-muted-foreground" />
              </div>
            )}
            <img
              src={quiz?.thumbnail}
              alt={quiz?.title}
              className={`w-full h-full object-cover transition-all duration-300 group-hover:scale-110 ${
                imageLoaded ? 'opacity-100' : 'opacity-0'
              }`}
              onLoad={() => setImageLoaded(true)}
              onError={() => setImageError(true)}
              loading="lazy"
            />
          </>
        )}
        
        {(!quiz?.thumbnail || imageError) && (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5">
            <Icon name="BookOpen" size={48} className="text-muted-foreground/40" />
          </div>
        )}

        {/* Enhanced status badge */}
        <div className="absolute top-3 left-3">
          <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border backdrop-blur-sm ${statusConfig?.color}`}>
            <Icon name={statusConfig?.icon} size={12} className="mr-1.5" />
            {statusConfig?.label}
          </span>
        </div>

        {/* Premium badge */}
        {quiz?.isPremium && (
          <div className="absolute top-3 right-3">
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-amber-400/90 to-yellow-500/90 text-white border border-amber-300/50 backdrop-blur-sm">
              <Icon name="Crown" size={10} className="mr-1" />
              Premium
            </span>
          </div>
        )}

        {/* Enhanced overlay with actions */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-200 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex space-x-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={(e) => {
                e?.stopPropagation();
                onView?.(quiz?.id);
              }}
              iconName="Eye"
              className="bg-white/90 hover:bg-white text-foreground shadow-lg backdrop-blur-sm"
            >
              Preview
            </Button>
          </div>
        </div>
      </div>
      {/* Enhanced content section */}
      <div className="p-5">
        <div className="mb-4">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-foreground line-clamp-2 leading-tight group-hover:text-primary transition-colors duration-200">
                {quiz?.title}
              </h3>
            </div>
          </div>
          
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="BookOpen" size={14} />
              <span className="font-medium">{quiz?.subject}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="HelpCircle" size={14} />
              <span>{quiz?.questionCount} questions</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={14} />
              <span>{quiz?.duration} min</span>
            </div>
          </div>
        </div>

        {/* Enhanced stats section */}
        <div className="bg-gradient-to-r from-muted/30 to-muted/20 rounded-lg p-3 mb-4">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-lg font-bold text-foreground">{quiz?.attempts}</div>
              <div className="text-xs text-muted-foreground">Attempts</div>
            </div>
            <div>
              <div className="text-lg font-bold text-success">{quiz?.averageScore}%</div>
              <div className="text-xs text-muted-foreground">Avg. Score</div>
            </div>
            <div>
              <div className="text-lg font-bold text-primary">{quiz?.completionRate}%</div>
              <div className="text-xs text-muted-foreground">Completed</div>
            </div>
          </div>
        </div>

        {/* Enhanced action buttons */}
        <div className="flex gap-2">
          <Button
            variant="default"
            size="sm"
            fullWidth
            onClick={() => onEdit?.(quiz?.id)}
            iconName="Edit"
            iconPosition="left"
            className="flex-1"
          >
            Edit
          </Button>
          
          <div className="flex gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onShare?.(quiz?.id)}
              iconName="Share2"
              className="px-3"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => onExport?.(quiz?.id)}
              iconName="Download"
              className="px-3"
            />
          </div>
        </div>

        {/* Creation date */}
        <div className="mt-3 pt-3 border-t border-border/50">
          <div className="text-xs text-muted-foreground flex items-center justify-between">
            <span>Created {new Date(quiz?.createdAt)?.toLocaleDateString()}</span>
            <div className="flex items-center space-x-1">
              <Icon name="Calendar" size={12} />
              <span>Updated recently</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizCard;