import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PremiumUpgradePrompt = ({ feature, onUpgrade, onDismiss }) => {
  const premiumFeatures = {
    'pdf_export': {
      title: 'PDF Export',
      description: 'Export your quizzes as professional PDF documents for offline use and printing.',
      icon: 'FileDown'
    },
    'lms_integration': {
      title: 'LMS Integration',
      description: 'Seamlessly integrate with popular Learning Management Systems like Moodle, Canvas, and Blackboard.',
      icon: 'Link'
    },
    'advanced_analytics': {
      title: 'Advanced Analytics',
      description: 'Get detailed insights into student performance with comprehensive analytics and reporting.',
      icon: 'BarChart3'
    },
    'unlimited_quizzes': {
      title: 'Unlimited Quizzes',
      description: 'Create unlimited quizzes without any restrictions on the number of questions or students.',
      icon: 'Infinity'
    }
  };

  const featureInfo = premiumFeatures?.[feature] || premiumFeatures?.['pdf_export'];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg shadow-lg max-w-md w-full">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
                <Icon name="Crown" size={20} className="text-warning" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Premium Feature</h3>
                <p className="text-sm text-muted-foreground">Upgrade to unlock</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onDismiss}
              iconName="X"
              className="px-2"
            />
          </div>

          {/* Feature Info */}
          <div className="mb-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name={featureInfo?.icon} size={16} className="text-primary" />
              </div>
              <h4 className="font-medium text-foreground">{featureInfo?.title}</h4>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {featureInfo?.description}
            </p>
          </div>

          {/* Premium Benefits */}
          <div className="mb-6">
            <h5 className="font-medium text-foreground mb-3">Premium includes:</h5>
            <ul className="space-y-2">
              {[
                'Unlimited quiz creation',
                'PDF export functionality',
                'LMS integration',
                'Advanced analytics',
                'Priority support',
                'Custom branding'
              ]?.map((benefit, index) => (
                <li key={index} className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Icon name="Check" size={16} className="text-success" />
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Pricing */}
          <div className="bg-muted rounded-lg p-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">$19.99</div>
              <div className="text-sm text-muted-foreground">per month</div>
              <div className="text-xs text-success mt-1">Save 20% with annual billing</div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={onDismiss}
              className="flex-1"
            >
              Maybe Later
            </Button>
            <Button
              variant="default"
              onClick={onUpgrade}
              iconName="Crown"
              iconPosition="left"
              className="flex-1"
            >
              Upgrade Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PremiumUpgradePrompt;