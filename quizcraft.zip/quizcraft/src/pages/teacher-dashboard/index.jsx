import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import PageHeader from '../../components/ui/PageHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import QuizCard from './components/QuizCard';
import StatsCard from './components/StatsCard';
import RecentActivity from './components/RecentActivity';
import QuizFilters from './components/QuizFilters';
import PremiumUpgradePrompt from './components/PremiumUpgradePrompt';

const TeacherDashboard = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [dateRange, setDateRange] = useState('all');
  const [showPremiumPrompt, setShowPremiumPrompt] = useState(false);
  const [premiumFeature, setPremiumFeature] = useState('');

  // Mock user data
  const currentUser = {
    id: 1,
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@school.edu",
    role: "teacher",
    isPremium: false
  };

  // Mock quiz data
  const mockQuizzes = [
    {
      id: 1,
      title: "Advanced Calculus - Derivatives and Integrals",
      subject: "Mathematics",
      thumbnail: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=200&fit=crop",
      questionCount: 25,
      duration: 45,
      attempts: 142,
      averageScore: 78,
      completionRate: 89,
      status: "active",
      createdAt: "2025-01-10T10:30:00Z",
      isPremium: false
    },
    {
      id: 2,
      title: "Photosynthesis and Cellular Respiration",
      subject: "Biology",
      thumbnail: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&h=200&fit=crop",
      questionCount: 20,
      duration: 30,
      attempts: 98,
      averageScore: 82,
      completionRate: 94,
      status: "active",
      createdAt: "2025-01-08T14:15:00Z",
      isPremium: true
    },
    {
      id: 3,
      title: "World War II - Causes and Consequences",
      subject: "History",
      thumbnail: "https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=400&h=200&fit=crop",
      questionCount: 30,
      duration: 60,
      attempts: 76,
      averageScore: 75,
      completionRate: 87,
      status: "draft",
      createdAt: "2025-01-05T09:45:00Z",
      isPremium: false
    },
    {
      id: 4,
      title: "Chemical Bonding and Molecular Structure",
      subject: "Chemistry",
      thumbnail: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=400&h=200&fit=crop",
      questionCount: 18,
      duration: 35,
      attempts: 54,
      averageScore: 71,
      completionRate: 82,
      status: "active",
      createdAt: "2025-01-03T16:20:00Z",
      isPremium: true
    },
    {
      id: 5,
      title: "Shakespeare\'s Hamlet - Literary Analysis",
      subject: "English",
      thumbnail: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=200&fit=crop",
      questionCount: 22,
      duration: 40,
      attempts: 89,
      averageScore: 84,
      completionRate: 91,
      status: "active",
      createdAt: "2024-12-28T11:10:00Z",
      isPremium: false
    },
    {
      id: 6,
      title: "Newton\'s Laws of Motion",
      subject: "Physics",
      thumbnail: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=400&h=200&fit=crop",
      questionCount: 15,
      duration: 25,
      attempts: 123,
      averageScore: 79,
      completionRate: 88,
      status: "archived",
      createdAt: "2024-12-20T13:30:00Z",
      isPremium: false
    }
  ];

  // Mock statistics data
  const statsData = [
    {
      title: "Total Quizzes",
      value: "24",
      change: "+3",
      changeType: "positive",
      icon: "FileText",
      description: "3 new quizzes this month"
    },
    {
      title: "Student Attempts",
      value: "1,247",
      change: "+12%",
      changeType: "positive",
      icon: "Users",
      description: "Increased engagement this week"
    },
    {
      title: "Average Score",
      value: "78%",
      change: "+2%",
      changeType: "positive",
      icon: "TrendingUp",
      description: "Improved from last month"
    },
    {
      title: "Premium Features",
      value: "0/10",
      change: "Upgrade",
      changeType: "neutral",
      icon: "Crown",
      description: "Unlock advanced features"
    }
  ];

  // Mock recent activity data
  const recentActivities = [
    {
      type: "quiz_attempt",
      user: "Emma Wilson",
      action: "completed quiz",
      target: "Advanced Calculus - Derivatives",
      timestamp: "2025-01-13T14:30:00Z",
      score: 85
    },
    {
      type: "quiz_shared",
      user: "You",
      action: "shared quiz",
      target: "Photosynthesis and Cellular Respiration",
      timestamp: "2025-01-13T13:15:00Z"
    },
    {
      type: "student_joined",
      user: "Michael Chen",
      action: "joined your class",
      timestamp: "2025-01-13T11:45:00Z"
    },
    {
      type: "quiz_completed",
      user: "Lisa Rodriguez",
      action: "completed quiz",
      target: "Chemical Bonding",
      timestamp: "2025-01-13T10:20:00Z",
      score: 92
    },
    {
      type: "quiz_attempt",
      user: "David Kim",
      action: "started quiz",
      target: "World War II - Causes",
      timestamp: "2025-01-13T09:30:00Z"
    }
  ];

  // Filter quizzes based on search and filters
  const filteredQuizzes = mockQuizzes?.filter(quiz => {
    const matchesSearch = quiz?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         quiz?.subject?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || quiz?.subject === selectedSubject;
    const matchesStatus = selectedStatus === 'all' || quiz?.status === selectedStatus;
    
    let matchesDate = true;
    if (dateRange !== 'all') {
      const quizDate = new Date(quiz.createdAt);
      const now = new Date();
      
      switch (dateRange) {
        case 'today':
          matchesDate = quizDate?.toDateString() === now?.toDateString();
          break;
        case 'week':
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          matchesDate = quizDate >= weekAgo;
          break;
        case 'month':
          matchesDate = quizDate?.getMonth() === now?.getMonth() && 
                       quizDate?.getFullYear() === now?.getFullYear();
          break;
        case 'quarter':
          const currentQuarter = Math.floor(now?.getMonth() / 3);
          const quizQuarter = Math.floor(quizDate?.getMonth() / 3);
          matchesDate = quizQuarter === currentQuarter && 
                       quizDate?.getFullYear() === now?.getFullYear();
          break;
        case 'year':
          matchesDate = quizDate?.getFullYear() === now?.getFullYear();
          break;
      }
    }
    
    return matchesSearch && matchesSubject && matchesStatus && matchesDate;
  });

  const handleNavigation = (path) => {
    navigate(path);
  };

  const handleCreateQuiz = () => {
    navigate('/quiz-creation');
  };

  const handleUploadNotes = () => {
    navigate('/quiz-creation?mode=upload');
  };

  const handleQuizEdit = (quizId) => {
    navigate(`/quiz-creation?edit=${quizId}`);
  };

  const handleQuizShare = (quizId) => {
    // Mock share functionality
    navigator.clipboard?.writeText(`${window.location?.origin}/quiz/${quizId}`);
    alert('Quiz link copied to clipboard!');
  };

  const handleQuizExport = (quizId) => {
    if (!currentUser?.isPremium) {
      setPremiumFeature('pdf_export');
      setShowPremiumPrompt(true);
      return;
    }
    // Mock export functionality
    alert('Quiz exported as PDF!');
  };

  const handleQuizView = (quizId) => {
    navigate(`/quiz/${quizId}`);
  };

  const handlePremiumUpgrade = () => {
    setShowPremiumPrompt(false);
    navigate('/upgrade');
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedSubject('all');
    setSelectedStatus('all');
    setDateRange('all');
  };

  const pageActions = [
    <Button
      key="upload"
      variant="outline"
      onClick={handleUploadNotes}
      iconName="Upload"
      iconPosition="left"
    >
      Upload Notes
    </Button>,
    <Button
      key="create"
      variant="default"
      onClick={handleCreateQuiz}
      iconName="Plus"
      iconPosition="left"
    >
      Create New Quiz
    </Button>
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header 
        user={currentUser} 
        currentPath="/teacher-dashboard"
        onNavigate={handleNavigation}
      />
      <div className="pt-16">
        <PageHeader
          title="Teacher Dashboard"
          subtitle="Manage your quizzes and track student progress"
          actions={pageActions}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsData?.map((stat, index) => (
              <StatsCard
                key={index}
                title={stat?.title}
                value={stat?.value}
                change={stat?.change}
                changeType={stat?.changeType}
                icon={stat?.icon}
                description={stat?.description}
              />
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content - Quiz Library */}
            <div className="lg:col-span-2">
              <div className="mb-6">
                <h2 className="text-xl font-semibold text-foreground mb-4">Quiz Library</h2>
                
                {/* Filters */}
                <QuizFilters
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  selectedSubject={selectedSubject}
                  onSubjectChange={setSelectedSubject}
                  selectedStatus={selectedStatus}
                  onStatusChange={setSelectedStatus}
                  dateRange={dateRange}
                  onDateRangeChange={setDateRange}
                  onClearFilters={handleClearFilters}
                />
              </div>

              {/* Quiz Grid */}
              {filteredQuizzes?.length === 0 ? (
                <div className="bg-card border border-border rounded-lg p-12 text-center">
                  <Icon name="FileText" size={48} className="text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">No quizzes found</h3>
                  <p className="text-muted-foreground mb-6">
                    {searchTerm || selectedSubject !== 'all' || selectedStatus !== 'all' || dateRange !== 'all' ?'Try adjusting your filters or search terms.' :'Create your first quiz to get started.'}
                  </p>
                  <Button
                    variant="default"
                    onClick={handleCreateQuiz}
                    iconName="Plus"
                    iconPosition="left"
                  >
                    Create New Quiz
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredQuizzes?.map((quiz) => (
                    <QuizCard
                      key={quiz?.id}
                      quiz={quiz}
                      onEdit={handleQuizEdit}
                      onShare={handleQuizShare}
                      onExport={handleQuizExport}
                      onView={handleQuizView}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Sidebar - Recent Activity */}
            <div className="lg:col-span-1">
              <RecentActivity activities={recentActivities} />
            </div>
          </div>
        </div>
      </div>
      {/* Premium Upgrade Prompt */}
      {showPremiumPrompt && (
        <PremiumUpgradePrompt
          feature={premiumFeature}
          onUpgrade={handlePremiumUpgrade}
          onDismiss={() => setShowPremiumPrompt(false)}
        />
      )}
    </div>
  );
};

export default TeacherDashboard;