import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const SecuritySection = ({ onChangePassword }) => {
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });

  const handleInputChange = (field, value) => {
    setPasswordData(prev => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const togglePasswordVisibility = (field) => {
    setShowPasswords(prev => ({ ...prev, [field]: !prev?.[field] }));
  };

  const validatePassword = (password) => {
    const minLength = password?.length >= 8;
    const hasUpperCase = /[A-Z]/?.test(password);
    const hasLowerCase = /[a-z]/?.test(password);
    const hasNumbers = /\d/?.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/?.test(password);
    
    return {
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar,
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar
    };
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!passwordData?.currentPassword) {
      newErrors.currentPassword = 'Current password is required';
    }
    
    if (!passwordData?.newPassword) {
      newErrors.newPassword = 'New password is required';
    } else {
      const validation = validatePassword(passwordData?.newPassword);
      if (!validation?.isValid) {
        newErrors.newPassword = 'Password does not meet security requirements';
      }
    }
    
    if (!passwordData?.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your new password';
    } else if (passwordData?.newPassword !== passwordData?.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleChangePassword = async () => {
    if (!validateForm()) return;
    
    setIsLoading(true);
    try {
      await onChangePassword(passwordData);
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setIsChangingPassword(false);
    } catch (error) {
      setErrors({ general: 'Failed to change password. Please check your current password.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    setErrors({});
    setIsChangingPassword(false);
  };

  const passwordValidation = validatePassword(passwordData?.newPassword);

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-warning rounded-full flex items-center justify-center">
            <Icon name="Shield" size={24} color="white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Security Settings</h2>
            <p className="text-sm text-muted-foreground">Manage your password and security preferences</p>
          </div>
        </div>
        {!isChangingPassword && (
          <Button
            variant="outline"
            iconName="Key"
            iconPosition="left"
            onClick={() => setIsChangingPassword(true)}
          >
            Change Password
          </Button>
        )}
      </div>
      {!isChangingPassword ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Lock" size={20} className="text-success" />
              <div>
                <p className="font-medium text-foreground">Password</p>
                <p className="text-sm text-muted-foreground">Last changed 30 days ago</p>
              </div>
            </div>
            <div className="text-sm text-success font-medium">Strong</div>
          </div>

          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Smartphone" size={20} className="text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Two-Factor Authentication</p>
                <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
              </div>
            </div>
            <Button variant="outline" size="sm">
              Enable
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Monitor" size={20} className="text-success" />
              <div>
                <p className="font-medium text-foreground">Active Sessions</p>
                <p className="text-sm text-muted-foreground">3 active sessions</p>
              </div>
            </div>
            <Button variant="outline" size="sm">
              Manage
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {errors?.general && (
            <div className="p-3 bg-error/10 border border-error/20 rounded-md">
              <p className="text-sm text-error">{errors?.general}</p>
            </div>
          )}

          <div className="relative">
            <Input
              label="Current Password"
              type={showPasswords?.current ? "text" : "password"}
              value={passwordData?.currentPassword}
              onChange={(e) => handleInputChange('currentPassword', e?.target?.value)}
              error={errors?.currentPassword}
              required
            />
            <button
              type="button"
              onClick={() => togglePasswordVisibility('current')}
              className="absolute right-3 top-9 text-muted-foreground hover:text-foreground"
            >
              <Icon name={showPasswords?.current ? "EyeOff" : "Eye"} size={16} />
            </button>
          </div>

          <div className="relative">
            <Input
              label="New Password"
              type={showPasswords?.new ? "text" : "password"}
              value={passwordData?.newPassword}
              onChange={(e) => handleInputChange('newPassword', e?.target?.value)}
              error={errors?.newPassword}
              required
            />
            <button
              type="button"
              onClick={() => togglePasswordVisibility('new')}
              className="absolute right-3 top-9 text-muted-foreground hover:text-foreground"
            >
              <Icon name={showPasswords?.new ? "EyeOff" : "Eye"} size={16} />
            </button>
          </div>

          {passwordData?.newPassword && (
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm font-medium text-foreground mb-2">Password Requirements:</p>
              <div className="space-y-1">
                <div className={`flex items-center space-x-2 text-xs ${passwordValidation?.minLength ? 'text-success' : 'text-muted-foreground'}`}>
                  <Icon name={passwordValidation?.minLength ? "Check" : "X"} size={12} />
                  <span>At least 8 characters</span>
                </div>
                <div className={`flex items-center space-x-2 text-xs ${passwordValidation?.hasUpperCase ? 'text-success' : 'text-muted-foreground'}`}>
                  <Icon name={passwordValidation?.hasUpperCase ? "Check" : "X"} size={12} />
                  <span>One uppercase letter</span>
                </div>
                <div className={`flex items-center space-x-2 text-xs ${passwordValidation?.hasLowerCase ? 'text-success' : 'text-muted-foreground'}`}>
                  <Icon name={passwordValidation?.hasLowerCase ? "Check" : "X"} size={12} />
                  <span>One lowercase letter</span>
                </div>
                <div className={`flex items-center space-x-2 text-xs ${passwordValidation?.hasNumbers ? 'text-success' : 'text-muted-foreground'}`}>
                  <Icon name={passwordValidation?.hasNumbers ? "Check" : "X"} size={12} />
                  <span>One number</span>
                </div>
                <div className={`flex items-center space-x-2 text-xs ${passwordValidation?.hasSpecialChar ? 'text-success' : 'text-muted-foreground'}`}>
                  <Icon name={passwordValidation?.hasSpecialChar ? "Check" : "X"} size={12} />
                  <span>One special character</span>
                </div>
              </div>
            </div>
          )}

          <div className="relative">
            <Input
              label="Confirm New Password"
              type={showPasswords?.confirm ? "text" : "password"}
              value={passwordData?.confirmPassword}
              onChange={(e) => handleInputChange('confirmPassword', e?.target?.value)}
              error={errors?.confirmPassword}
              required
            />
            <button
              type="button"
              onClick={() => togglePasswordVisibility('confirm')}
              className="absolute right-3 top-9 text-muted-foreground hover:text-foreground"
            >
              <Icon name={showPasswords?.confirm ? "EyeOff" : "Eye"} size={16} />
            </button>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-border">
            <Button
              variant="outline"
              onClick={handleCancel}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              onClick={handleChangePassword}
              loading={isLoading}
              iconName="Save"
              iconPosition="left"
            >
              Change Password
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecuritySection;