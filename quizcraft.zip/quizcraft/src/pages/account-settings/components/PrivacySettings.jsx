import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';

const PrivacySettings = ({ privacySettings, onUpdatePrivacy }) => {
  const [settings, setSettings] = useState({
    profileVisibility: privacySettings?.profileVisibility || 'private',
    allowDataCollection: privacySettings?.allowDataCollection || false,
    shareAnalytics: privacySettings?.shareAnalytics || false,
    allowQuizSharing: privacySettings?.allowQuizSharing || true,
    showInDirectory: privacySettings?.showInDirectory || false,
    allowContactFromStudents: privacySettings?.allowContactFromStudents || true,
    dataRetention: privacySettings?.dataRetention || '1year',
    cookiePreferences: privacySettings?.cookiePreferences || 'essential'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const visibilityOptions = [
    { value: 'public', label: 'Public - Anyone can see your profile' },
    { value: 'institution', label: 'Institution Only - Only members of your institution' },
    { value: 'private', label: 'Private - Only you can see your profile' }
  ];

  const retentionOptions = [
    { value: '6months', label: '6 months' },
    { value: '1year', label: '1 year' },
    { value: '2years', label: '2 years' },
    { value: 'indefinite', label: 'Keep indefinitely' }
  ];

  const cookieOptions = [
    { value: 'essential', label: 'Essential cookies only' },
    { value: 'functional', label: 'Essential + Functional cookies' },
    { value: 'all', label: 'All cookies (including analytics)' }
  ];

  const handleSettingChange = (setting, value) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      await onUpdatePrivacy(settings);
      setHasChanges(false);
    } catch (error) {
      console.error('Failed to update privacy settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setSettings({
      profileVisibility: privacySettings?.profileVisibility || 'private',
      allowDataCollection: privacySettings?.allowDataCollection || false,
      shareAnalytics: privacySettings?.shareAnalytics || false,
      allowQuizSharing: privacySettings?.allowQuizSharing || true,
      showInDirectory: privacySettings?.showInDirectory || false,
      allowContactFromStudents: privacySettings?.allowContactFromStudents || true,
      dataRetention: privacySettings?.dataRetention || '1year',
      cookiePreferences: privacySettings?.cookiePreferences || 'essential'
    });
    setHasChanges(false);
  };

  const handleDeleteAccount = () => {
    setShowDeleteConfirm(true);
  };

  const confirmDeleteAccount = async () => {
    setIsLoading(true);
    try {
      // Mock delete account process
      console.log('Account deletion requested');
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error('Failed to delete account');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center">
            <Icon name="Shield" size={24} color="white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Privacy & Data</h2>
            <p className="text-sm text-muted-foreground">Control your privacy and data sharing preferences</p>
          </div>
        </div>
      </div>
      <div className="space-y-8">
        {/* Profile Visibility */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 pb-2 border-b border-border">
            <Icon name="Eye" size={20} className="text-primary" />
            <div>
              <h3 className="font-medium text-foreground">Profile Visibility</h3>
              <p className="text-sm text-muted-foreground">Control who can see your profile information</p>
            </div>
          </div>
          
          <div className="pl-8">
            <Select
              label="Profile Visibility Level"
              options={visibilityOptions}
              value={settings?.profileVisibility}
              onChange={(value) => handleSettingChange('profileVisibility', value)}
              className="max-w-md"
            />
          </div>
        </div>

        {/* Data Collection */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 pb-2 border-b border-border">
            <Icon name="Database" size={20} className="text-primary" />
            <div>
              <h3 className="font-medium text-foreground">Data Collection</h3>
              <p className="text-sm text-muted-foreground">Manage how your data is collected and used</p>
            </div>
          </div>

          <div className="space-y-4 pl-8">
            <div className="flex items-start space-x-3">
              <Checkbox
                checked={settings?.allowDataCollection}
                onChange={(e) => handleSettingChange('allowDataCollection', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">
                  Allow Usage Data Collection
                </label>
                <p className="text-sm text-muted-foreground">
                  Help us improve QuizCraft by sharing anonymous usage data
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                checked={settings?.shareAnalytics}
                onChange={(e) => handleSettingChange('shareAnalytics', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">
                  Share Analytics Data
                </label>
                <p className="text-sm text-muted-foreground">
                  Share aggregated analytics to help improve educational outcomes
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Sharing Preferences */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 pb-2 border-b border-border">
            <Icon name="Share" size={20} className="text-primary" />
            <div>
              <h3 className="font-medium text-foreground">Sharing Preferences</h3>
              <p className="text-sm text-muted-foreground">Control how others can interact with your content</p>
            </div>
          </div>

          <div className="space-y-4 pl-8">
            <div className="flex items-start space-x-3">
              <Checkbox
                checked={settings?.allowQuizSharing}
                onChange={(e) => handleSettingChange('allowQuizSharing', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">
                  Allow Quiz Sharing
                </label>
                <p className="text-sm text-muted-foreground">
                  Let other educators share quizzes with you
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                checked={settings?.showInDirectory}
                onChange={(e) => handleSettingChange('showInDirectory', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">
                  Show in Educator Directory
                </label>
                <p className="text-sm text-muted-foreground">
                  Appear in the public educator directory for collaboration
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                checked={settings?.allowContactFromStudents}
                onChange={(e) => handleSettingChange('allowContactFromStudents', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">
                  Allow Student Contact
                </label>
                <p className="text-sm text-muted-foreground">
                  Let students contact you directly through the platform
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Data Retention */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 pb-2 border-b border-border">
            <Icon name="Clock" size={20} className="text-primary" />
            <div>
              <h3 className="font-medium text-foreground">Data Retention</h3>
              <p className="text-sm text-muted-foreground">Choose how long to keep your data</p>
            </div>
          </div>

          <div className="pl-8">
            <Select
              label="Data Retention Period"
              description="How long should we keep your quiz data and analytics?"
              options={retentionOptions}
              value={settings?.dataRetention}
              onChange={(value) => handleSettingChange('dataRetention', value)}
              className="max-w-md"
            />
          </div>
        </div>

        {/* Cookie Preferences */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 pb-2 border-b border-border">
            <Icon name="Cookie" size={20} className="text-primary" />
            <div>
              <h3 className="font-medium text-foreground">Cookie Preferences</h3>
              <p className="text-sm text-muted-foreground">Manage cookie usage on our platform</p>
            </div>
          </div>

          <div className="pl-8">
            <Select
              label="Cookie Settings"
              description="Choose which cookies you want to allow"
              options={cookieOptions}
              value={settings?.cookiePreferences}
              onChange={(value) => handleSettingChange('cookiePreferences', value)}
              className="max-w-md"
            />
          </div>
        </div>

        {/* Account Deletion */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 pb-2 border-b border-error/20">
            <Icon name="Trash2" size={20} className="text-error" />
            <div>
              <h3 className="font-medium text-error">Danger Zone</h3>
              <p className="text-sm text-muted-foreground">Irreversible actions for your account</p>
            </div>
          </div>

          <div className="pl-8">
            <div className="p-4 bg-error/5 border border-error/20 rounded-lg">
              <h4 className="font-medium text-error mb-2">Delete Account</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Permanently delete your account and all associated data. This action cannot be undone.
              </p>
              <Button
                variant="destructive"
                onClick={handleDeleteAccount}
                iconName="Trash2"
                iconPosition="left"
              >
                Delete Account
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Save Changes */}
      {hasChanges && (
        <div className="flex items-center justify-between pt-6 mt-6 border-t border-border">
          <p className="text-sm text-muted-foreground">You have unsaved changes</p>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={handleReset}
              disabled={isLoading}
            >
              Reset
            </Button>
            <Button
              variant="default"
              onClick={handleSave}
              loading={isLoading}
              iconName="Save"
              iconPosition="left"
            >
              Save Changes
            </Button>
          </div>
        </div>
      )}
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card p-6 rounded-lg border border-border max-w-md w-full mx-4">
            <div className="flex items-center space-x-3 mb-4">
              <Icon name="AlertTriangle" size={24} className="text-error" />
              <h3 className="text-lg font-semibold text-foreground">Delete Account</h3>
            </div>
            <p className="text-muted-foreground mb-6">
              Are you sure you want to delete your account? This will permanently remove all your quizzes, 
              student data, and account information. This action cannot be undone.
            </p>
            <div className="flex items-center justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowDeleteConfirm(false)}
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={confirmDeleteAccount}
                loading={isLoading}
                iconName="Trash2"
                iconPosition="left"
              >
                Delete Account
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PrivacySettings;