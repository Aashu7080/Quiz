import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const NotificationSettings = ({ preferences, onUpdatePreferences }) => {
  const [settings, setSettings] = useState({
    emailNotifications: preferences?.emailNotifications || true,
    quizShares: preferences?.quizShares || true,
    studentAttempts: preferences?.studentAttempts || true,
    systemUpdates: preferences?.systemUpdates || false,
    weeklyDigest: preferences?.weeklyDigest || true,
    marketingEmails: preferences?.marketingEmails || false,
    pushNotifications: preferences?.pushNotifications || true,
    browserNotifications: preferences?.browserNotifications || false,
    smsNotifications: preferences?.smsNotifications || false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const handleSettingChange = (setting, value) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      await onUpdatePreferences(settings);
      setHasChanges(false);
    } catch (error) {
      console.error('Failed to update notification preferences');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setSettings({
      emailNotifications: preferences?.emailNotifications || true,
      quizShares: preferences?.quizShares || true,
      studentAttempts: preferences?.studentAttempts || true,
      systemUpdates: preferences?.systemUpdates || false,
      weeklyDigest: preferences?.weeklyDigest || true,
      marketingEmails: preferences?.marketingEmails || false,
      pushNotifications: preferences?.pushNotifications || true,
      browserNotifications: preferences?.browserNotifications || false,
      smsNotifications: preferences?.smsNotifications || false
    });
    setHasChanges(false);
  };

  const notificationGroups = [
    {
      title: 'Email Notifications',
      description: 'Receive updates and alerts via email',
      icon: 'Mail',
      settings: [
        {
          key: 'emailNotifications',
          label: 'Enable Email Notifications',
          description: 'Master toggle for all email notifications'
        },
        {
          key: 'quizShares',
          label: 'Quiz Shares',
          description: 'When someone shares a quiz with you',
          dependent: 'emailNotifications'
        },
        {
          key: 'studentAttempts',
          label: 'Student Quiz Attempts',
          description: 'When students complete your quizzes',
          dependent: 'emailNotifications'
        },
        {
          key: 'systemUpdates',
          label: 'System Updates',
          description: 'Important platform updates and maintenance',
          dependent: 'emailNotifications'
        },
        {
          key: 'weeklyDigest',
          label: 'Weekly Activity Digest',
          description: 'Summary of your weekly quiz activity',
          dependent: 'emailNotifications'
        },
        {
          key: 'marketingEmails',
          label: 'Marketing & Promotions',
          description: 'Product updates and special offers',
          dependent: 'emailNotifications'
        }
      ]
    },
    {
      title: 'Push Notifications',
      description: 'Real-time notifications on your devices',
      icon: 'Bell',
      settings: [
        {
          key: 'pushNotifications',
          label: 'Enable Push Notifications',
          description: 'Receive notifications on your mobile device'
        },
        {
          key: 'browserNotifications',
          label: 'Browser Notifications',
          description: 'Show notifications in your web browser',
          dependent: 'pushNotifications'
        }
      ]
    },
    {
      title: 'SMS Notifications',
      description: 'Text message alerts for critical updates',
      icon: 'MessageSquare',
      settings: [
        {
          key: 'smsNotifications',
          label: 'Enable SMS Notifications',
          description: 'Receive important alerts via text message'
        }
      ]
    }
  ];

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
            <Icon name="Bell" size={24} color="white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Notification Preferences</h2>
            <p className="text-sm text-muted-foreground">Control how and when you receive notifications</p>
          </div>
        </div>
      </div>
      <div className="space-y-8">
        {notificationGroups?.map((group) => (
          <div key={group?.title} className="space-y-4">
            <div className="flex items-center space-x-3 pb-2 border-b border-border">
              <Icon name={group?.icon} size={20} className="text-primary" />
              <div>
                <h3 className="font-medium text-foreground">{group?.title}</h3>
                <p className="text-sm text-muted-foreground">{group?.description}</p>
              </div>
            </div>

            <div className="space-y-4 pl-8">
              {group?.settings?.map((setting) => (
                <div key={setting?.key} className="flex items-start space-x-3">
                  <Checkbox
                    checked={settings?.[setting?.key]}
                    onChange={(e) => handleSettingChange(setting?.key, e?.target?.checked)}
                    disabled={setting?.dependent && !settings?.[setting?.dependent]}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <label className={`block font-medium ${
                      setting?.dependent && !settings?.[setting?.dependent] 
                        ? 'text-muted-foreground' 
                        : 'text-foreground'
                    }`}>
                      {setting?.label}
                    </label>
                    <p className={`text-sm ${
                      setting?.dependent && !settings?.[setting?.dependent] 
                        ? 'text-muted-foreground' 
                        : 'text-muted-foreground'
                    }`}>
                      {setting?.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      {hasChanges && (
        <div className="flex items-center justify-between pt-6 mt-6 border-t border-border">
          <p className="text-sm text-muted-foreground">You have unsaved changes</p>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={handleReset}
              disabled={isLoading}
            >
              Reset
            </Button>
            <Button
              variant="default"
              onClick={handleSave}
              loading={isLoading}
              iconName="Save"
              iconPosition="left"
            >
              Save Preferences
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationSettings;