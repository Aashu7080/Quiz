import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SubscriptionSection = ({ subscription, onUpgrade, onManageBilling }) => {
  const [isLoading, setIsLoading] = useState(false);

  const currentPlan = subscription || {
    plan: 'free',
    status: 'active',
    nextBilling: null,
    features: {
      quizzesPerMonth: 10,
      studentsPerQuiz: 30,
      pdfExport: false,
      lmsIntegration: false,
      analytics: false,
      priority: false
    },
    usage: {
      quizzesUsed: 7,
      studentsReached: 156
    }
  };

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '$0',
      period: 'forever',
      description: 'Perfect for getting started',
      features: [
        '10 quizzes per month',
        'Up to 30 students per quiz',
        'Basic question types',
        'Email support',
        'Quiz sharing'
      ],
      limitations: [
        'No PDF export',
        'No LMS integration',
        'Limited analytics'
      ]
    },
    {
      id: 'pro',
      name: 'Professional',
      price: '$19',
      period: 'per month',
      description: 'For serious educators',
      features: [
        'Unlimited quizzes',
        'Unlimited students',
        'PDF export',
        'Advanced analytics',
        'Priority support',
        'Custom branding',
        'Bulk operations'
      ],
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: '$49',
      period: 'per month',
      description: 'For institutions',
      features: [
        'Everything in Professional',
        'LMS integration',
        'SSO authentication',
        'Advanced reporting',
        'API access',
        'Dedicated support',
        'Custom features'
      ]
    }
  ];

  const handleUpgrade = async (planId) => {
    setIsLoading(true);
    try {
      await onUpgrade(planId);
    } catch (error) {
      console.error('Failed to upgrade subscription');
    } finally {
      setIsLoading(false);
    }
  };

  const handleManageBilling = async () => {
    setIsLoading(true);
    try {
      await onManageBilling();
    } catch (error) {
      console.error('Failed to open billing portal');
    } finally {
      setIsLoading(false);
    }
  };

  const getUsagePercentage = (used, total) => {
    if (total === 0) return 0;
    return Math.min((used / total) * 100, 100);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-success rounded-full flex items-center justify-center">
            <Icon name="CreditCard" size={24} color="white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Subscription & Billing</h2>
            <p className="text-sm text-muted-foreground">Manage your plan and billing information</p>
          </div>
        </div>
      </div>
      {/* Current Plan Status */}
      <div className="mb-8 p-4 bg-muted rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground capitalize">
              {currentPlan?.plan} Plan
            </h3>
            <p className="text-sm text-muted-foreground">
              {currentPlan?.plan === 'free' ?'You are currently on the free plan' 
                : `Next billing: ${currentPlan?.nextBilling || 'January 15, 2025'}`
              }
            </p>
          </div>
          <div className={`px-3 py-1 rounded-full text-xs font-medium ${
            currentPlan?.status === 'active' ?'bg-success/10 text-success' :'bg-warning/10 text-warning'
          }`}>
            {currentPlan?.status}
          </div>
        </div>

        {/* Usage Statistics */}
        {currentPlan?.plan === 'free' && (
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-muted-foreground">Quizzes this month</span>
                <span className="text-foreground">
                  {currentPlan?.usage?.quizzesUsed} / {currentPlan?.features?.quizzesPerMonth}
                </span>
              </div>
              <div className="w-full bg-border rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${getUsagePercentage(currentPlan?.usage?.quizzesUsed, currentPlan?.features?.quizzesPerMonth)}%` 
                  }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-muted-foreground">Students reached</span>
                <span className="text-foreground">{currentPlan?.usage?.studentsReached}</span>
              </div>
            </div>
          </div>
        )}

        {currentPlan?.plan !== 'free' && (
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={handleManageBilling}
              loading={isLoading}
              iconName="ExternalLink"
              iconPosition="right"
            >
              Manage Billing
            </Button>
          </div>
        )}
      </div>
      {/* Available Plans */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Available Plans</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans?.map((plan) => (
            <div 
              key={plan?.id}
              className={`relative p-6 rounded-lg border ${
                plan?.popular 
                  ? 'border-primary bg-primary/5' :'border-border bg-card'
              } ${
                currentPlan?.plan === plan?.id 
                  ? 'ring-2 ring-primary' :''
              }`}
            >
              {plan?.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-medium">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="text-center mb-4">
                <h4 className="text-lg font-semibold text-foreground">{plan?.name}</h4>
                <div className="mt-2">
                  <span className="text-3xl font-bold text-foreground">{plan?.price}</span>
                  <span className="text-sm text-muted-foreground">/{plan?.period}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">{plan?.description}</p>
              </div>

              <ul className="space-y-2 mb-6">
                {plan?.features?.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2 text-sm">
                    <Icon name="Check" size={16} className="text-success" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
                {plan?.limitations?.map((limitation, index) => (
                  <li key={index} className="flex items-center space-x-2 text-sm">
                    <Icon name="X" size={16} className="text-muted-foreground" />
                    <span className="text-muted-foreground">{limitation}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={currentPlan?.plan === plan?.id ? "outline" : "default"}
                fullWidth
                disabled={currentPlan?.plan === plan?.id || isLoading}
                onClick={() => handleUpgrade(plan?.id)}
                loading={isLoading}
              >
                {currentPlan?.plan === plan?.id ? 'Current Plan' : `Upgrade to ${plan?.name}`}
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* Billing History */}
      {currentPlan?.plan !== 'free' && (
        <div className="mt-8 pt-6 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Recent Billing History</h3>
          <div className="space-y-3">
            {[
              { date: 'Dec 15, 2024', amount: '$19.00', status: 'paid', invoice: 'INV-2024-12-001' },
              { date: 'Nov 15, 2024', amount: '$19.00', status: 'paid', invoice: 'INV-2024-11-001' },
              { date: 'Oct 15, 2024', amount: '$19.00', status: 'paid', invoice: 'INV-2024-10-001' }
            ]?.map((bill, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-3">
                  <Icon name="Receipt" size={16} className="text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{bill?.invoice}</p>
                    <p className="text-xs text-muted-foreground">{bill?.date}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-sm font-medium text-foreground">{bill?.amount}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    bill?.status === 'paid' ?'bg-success/10 text-success' :'bg-warning/10 text-warning'
                  }`}>
                    {bill?.status}
                  </span>
                  <Button variant="ghost" size="sm" iconName="Download" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionSection;