import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const ExportSection = ({ onExportData }) => {
  const [exportSettings, setExportSettings] = useState({
    dataType: 'all',
    format: 'json',
    dateRange: '1year',
    includeStudentData: true,
    includeAnalytics: true,
    includeQuizContent: true,
    includeAttempts: true
  });
  const [isExporting, setIsExporting] = useState(false);
  const [exportHistory, setExportHistory] = useState([
    {
      id: 1,
      type: 'Full Export',
      format: 'JSON',
      date: '2024-12-15',
      size: '2.4 MB',
      status: 'completed'
    },
    {
      id: 2,
      type: 'Quiz Data Only',
      format: 'CSV',
      date: '2024-11-28',
      size: '856 KB',
      status: 'completed'
    },
    {
      id: 3,
      type: 'Analytics Export',
      format: 'PDF',
      date: '2024-11-15',
      size: '1.2 MB',
      status: 'completed'
    }
  ]);

  const dataTypeOptions = [
    { value: 'all', label: 'All Data - Complete account export' },
    { value: 'quizzes', label: 'Quizzes Only - Quiz content and settings' },
    { value: 'analytics', label: 'Analytics Only - Performance and usage data' },
    { value: 'students', label: 'Student Data - Student information and attempts' }
  ];

  const formatOptions = [
    { value: 'json', label: 'JSON - Machine readable format' },
    { value: 'csv', label: 'CSV - Spreadsheet compatible' },
    { value: 'pdf', label: 'PDF - Human readable report' },
    { value: 'xlsx', label: 'Excel - Microsoft Excel format' }
  ];

  const dateRangeOptions = [
    { value: '1month', label: 'Last Month' },
    { value: '3months', label: 'Last 3 Months' },
    { value: '6months', label: 'Last 6 Months' },
    { value: '1year', label: 'Last Year' },
    { value: 'all', label: 'All Time' }
  ];

  const handleSettingChange = (setting, value) => {
    setExportSettings(prev => ({ ...prev, [setting]: value }));
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await onExportData(exportSettings);
      // Add to export history
      const newExport = {
        id: exportHistory?.length + 1,
        type: dataTypeOptions?.find(opt => opt?.value === exportSettings?.dataType)?.label?.split(' - ')?.[0],
        format: exportSettings?.format?.toUpperCase(),
        date: new Date()?.toISOString()?.split('T')?.[0],
        size: '1.8 MB', // Mock size
        status: 'completed'
      };
      setExportHistory(prev => [newExport, ...prev]);
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = (exportId) => {
    // Mock download functionality
    console.log(`Downloading export ${exportId}`);
  };

  const getEstimatedSize = () => {
    let baseSize = 0;
    switch (exportSettings?.dataType) {
      case 'all': baseSize = 2500; break;
      case 'quizzes': baseSize = 800; break;
      case 'analytics': baseSize = 400; break;
      case 'students': baseSize = 600; break;
      default: baseSize = 1000;
    }

    // Adjust based on format
    const formatMultiplier = {
      json: 1,
      csv: 0.6,
      pdf: 1.5,
      xlsx: 0.8
    };

    const estimatedKB = baseSize * (formatMultiplier?.[exportSettings?.format] || 1);
    return estimatedKB > 1000 ? `${(estimatedKB / 1000)?.toFixed(1)} MB` : `${Math.round(estimatedKB)} KB`;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
            <Icon name="Download" size={24} color="white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Data Export</h2>
            <p className="text-sm text-muted-foreground">Download your data and quiz history</p>
          </div>
        </div>
      </div>
      {/* Export Configuration */}
      <div className="space-y-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Select
            label="Data Type"
            description="Choose what data to include in the export"
            options={dataTypeOptions}
            value={exportSettings?.dataType}
            onChange={(value) => handleSettingChange('dataType', value)}
          />

          <Select
            label="Export Format"
            description="Select the file format for your export"
            options={formatOptions}
            value={exportSettings?.format}
            onChange={(value) => handleSettingChange('format', value)}
          />

          <Select
            label="Date Range"
            description="Choose the time period for your data"
            options={dateRangeOptions}
            value={exportSettings?.dateRange}
            onChange={(value) => handleSettingChange('dateRange', value)}
            className="md:col-span-2"
          />
        </div>

        {/* Advanced Options */}
        <div className="space-y-4">
          <h3 className="font-medium text-foreground">Include in Export</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start space-x-3">
              <Checkbox
                checked={exportSettings?.includeQuizContent}
                onChange={(e) => handleSettingChange('includeQuizContent', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">Quiz Content</label>
                <p className="text-sm text-muted-foreground">Questions, answers, and quiz settings</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                checked={exportSettings?.includeStudentData}
                onChange={(e) => handleSettingChange('includeStudentData', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">Student Information</label>
                <p className="text-sm text-muted-foreground">Student profiles and contact details</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                checked={exportSettings?.includeAttempts}
                onChange={(e) => handleSettingChange('includeAttempts', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">Quiz Attempts</label>
                <p className="text-sm text-muted-foreground">Student responses and scores</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                checked={exportSettings?.includeAnalytics}
                onChange={(e) => handleSettingChange('includeAnalytics', e?.target?.checked)}
                className="mt-1"
              />
              <div>
                <label className="block font-medium text-foreground">Analytics Data</label>
                <p className="text-sm text-muted-foreground">Performance metrics and insights</p>
              </div>
            </div>
          </div>
        </div>

        {/* Export Summary */}
        <div className="p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-foreground">Export Summary</h4>
              <p className="text-sm text-muted-foreground">
                {dataTypeOptions?.find(opt => opt?.value === exportSettings?.dataType)?.label?.split(' - ')?.[0]} • 
                {exportSettings?.format?.toUpperCase()} format • 
                {dateRangeOptions?.find(opt => opt?.value === exportSettings?.dateRange)?.label}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-foreground">Estimated Size</p>
              <p className="text-sm text-muted-foreground">{getEstimatedSize()}</p>
            </div>
          </div>
        </div>

        <Button
          variant="default"
          onClick={handleExport}
          loading={isExporting}
          iconName="Download"
          iconPosition="left"
          className="w-full md:w-auto"
        >
          {isExporting ? 'Preparing Export...' : 'Start Export'}
        </Button>
      </div>
      {/* Export History */}
      <div className="pt-6 border-t border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Export History</h3>
        <div className="space-y-3">
          {exportHistory?.map((exportItem) => (
            <div key={exportItem?.id} className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
                  <Icon name="FileText" size={20} color="white" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">{exportItem?.type}</h4>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span>{exportItem?.format}</span>
                    <span>•</span>
                    <span>{exportItem?.date}</span>
                    <span>•</span>
                    <span>{exportItem?.size}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  exportItem?.status === 'completed' 
                    ? 'bg-success/10 text-success' :'bg-warning/10 text-warning'
                }`}>
                  {exportItem?.status}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDownload(exportItem?.id)}
                  iconName="Download"
                >
                  Download
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 p-3 bg-muted/50 rounded-lg">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Icon name="Info" size={16} />
            <span>Export files are available for download for 30 days after creation.</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExportSection;