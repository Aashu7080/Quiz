import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const IntegrationSettings = ({ integrations, onConnectIntegration, onDisconnectIntegration }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [connectingService, setConnectingService] = useState(null);

  const availableIntegrations = [
    {
      id: 'moodle',
      name: 'Moodle',
      description: 'Sync quizzes with your Moodle courses',
      icon: 'BookOpen',
      status: integrations?.moodle?.connected || false,
      premium: true,
      config: integrations?.moodle || {}
    },
    {
      id: 'canvas',
      name: 'Canvas LMS',
      description: 'Import and export quizzes to Canvas',
      icon: 'Layers',
      status: integrations?.canvas?.connected || false,
      premium: true,
      config: integrations?.canvas || {}
    },
    {
      id: 'blackboard',
      name: 'Blackboard',
      description: 'Integrate with Blackboard Learn',
      icon: 'Monitor',
      status: integrations?.blackboard?.connected || false,
      premium: true,
      config: integrations?.blackboard || {}
    },
    {
      id: 'googledrive',
      name: 'Google Drive',
      description: 'Save and sync quiz files to Google Drive',
      icon: 'Cloud',
      status: integrations?.googledrive?.connected || true,
      premium: false,
      config: integrations?.googledrive || {}
    },
    {
      id: 'onedrive',
      name: 'OneDrive',
      description: 'Backup quizzes to Microsoft OneDrive',
      icon: 'HardDrive',
      status: integrations?.onedrive?.connected || false,
      premium: false,
      config: integrations?.onedrive || {}
    },
    {
      id: 'zoom',
      name: 'Zoom',
      description: 'Create quiz sessions in Zoom meetings',
      icon: 'Video',
      status: integrations?.zoom?.connected || false,
      premium: true,
      config: integrations?.zoom || {}
    }
  ];

  const handleConnect = async (serviceId) => {
    setIsLoading(true);
    setConnectingService(serviceId);
    try {
      await onConnectIntegration(serviceId);
    } catch (error) {
      console.error(`Failed to connect ${serviceId}`);
    } finally {
      setIsLoading(false);
      setConnectingService(null);
    }
  };

  const handleDisconnect = async (serviceId) => {
    setIsLoading(true);
    try {
      await onDisconnectIntegration(serviceId);
    } catch (error) {
      console.error(`Failed to disconnect ${serviceId}`);
    } finally {
      setIsLoading(false);
    }
  };

  const connectedIntegrations = availableIntegrations?.filter(integration => integration?.status);
  const availableServices = availableIntegrations?.filter(integration => !integration?.status);

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
            <Icon name="Zap" size={24} color="white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-foreground">Integrations</h2>
            <p className="text-sm text-muted-foreground">Connect QuizCraft with your favorite tools</p>
          </div>
        </div>
      </div>
      {/* Connected Integrations */}
      {connectedIntegrations?.length > 0 && (
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">Connected Services</h3>
          <div className="space-y-4">
            {connectedIntegrations?.map((integration) => (
              <div key={integration?.id} className="flex items-center justify-between p-4 bg-success/5 border border-success/20 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
                    <Icon name={integration?.icon} size={20} color="white" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="font-medium text-foreground">{integration?.name}</h4>
                      {integration?.premium && (
                        <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                          Premium
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{integration?.description}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Icon name="CheckCircle" size={14} className="text-success" />
                      <span className="text-xs text-success">Connected</span>
                      {integration?.config?.lastSync && (
                        <span className="text-xs text-muted-foreground">
                          • Last sync: {integration?.config?.lastSync}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Settings"
                    onClick={() => console.log(`Configure ${integration?.id}`)}
                  >
                    Configure
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Unlink"
                    onClick={() => handleDisconnect(integration?.id)}
                    disabled={isLoading}
                  >
                    Disconnect
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Available Integrations */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Available Integrations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {availableServices?.map((integration) => (
            <div key={integration?.id} className="p-4 border border-border rounded-lg hover:border-primary/50 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                    <Icon name={integration?.icon} size={20} className="text-muted-foreground" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="font-medium text-foreground">{integration?.name}</h4>
                      {integration?.premium && (
                        <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                          Premium
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{integration?.description}</p>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                fullWidth
                onClick={() => handleConnect(integration?.id)}
                loading={connectingService === integration?.id}
                disabled={isLoading || (integration?.premium && !integration?.hasPremium)}
                iconName="Plus"
                iconPosition="left"
              >
                {integration?.premium && !integration?.hasPremium 
                  ? 'Upgrade Required' :'Connect'
                }
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* API Access Section */}
      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex items-center space-x-3 mb-4">
          <Icon name="Code" size={20} className="text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">API Access</h3>
            <p className="text-sm text-muted-foreground">Integrate QuizCraft with custom applications</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-foreground">API Key</h4>
              <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                Premium Feature
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Use our REST API to integrate QuizCraft functionality into your applications
            </p>
            <div className="flex items-center space-x-3">
              <Input
                type="password"
                value="qc_sk_1234567890abcdef"
                disabled
                className="flex-1"
              />
              <Button variant="outline" size="sm" iconName="Copy">
                Copy
              </Button>
              <Button variant="outline" size="sm" iconName="RotateCcw">
                Regenerate
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">API Documentation</p>
              <p className="text-sm text-muted-foreground">Learn how to integrate with our API</p>
            </div>
            <Button
              variant="outline"
              iconName="ExternalLink"
              iconPosition="right"
              onClick={() => window.open('https://docs.quizcraft.com/api', '_blank')}
            >
              View Docs
            </Button>
          </div>
        </div>
      </div>
      {/* Webhooks Section */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Icon name="Webhook" size={20} className="text-primary" />
            <div>
              <h3 className="text-lg font-semibold text-foreground">Webhooks</h3>
              <p className="text-sm text-muted-foreground">Receive real-time notifications about quiz events</p>
            </div>
          </div>
          <Button variant="outline" iconName="Plus" iconPosition="left">
            Add Webhook
          </Button>
        </div>

        <div className="space-y-3">
          {[
            { url: 'https://api.myschool.edu/webhooks/quiz-completed', events: ['quiz.completed', 'quiz.shared'] },
            { url: 'https://analytics.myschool.edu/quiz-events', events: ['quiz.created', 'quiz.attempted'] }
          ]?.map((webhook, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">{webhook?.url}</p>
                <p className="text-xs text-muted-foreground">
                  Events: {webhook?.events?.join(', ')}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" iconName="Edit" />
                <Button variant="ghost" size="sm" iconName="Trash2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IntegrationSettings;