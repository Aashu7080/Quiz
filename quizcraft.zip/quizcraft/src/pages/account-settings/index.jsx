import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import PageHeader from '../../components/ui/PageHeader';
import ProfileSection from './components/ProfileSection';
import SecuritySection from './components/SecuritySection';
import NotificationSettings from './components/NotificationSettings';
import SubscriptionSection from './components/SubscriptionSection';
import PrivacySettings from './components/PrivacySettings';
import IntegrationSettings from './components/IntegrationSettings';
import ExportSection from './components/ExportSection';
import Icon from '../../components/AppIcon';

const AccountSettings = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profile');
  const [user, setUser] = useState({
    id: 1,
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@university.edu",
    role: "teacher",
    institution: "Springfield University",
    phone: "+1 (555) 123-4567",
    bio: "Professor of Computer Science with 10+ years of experience in educational technology and online learning platforms."
  });

  const [subscription, setSubscription] = useState({
    plan: 'pro',
    status: 'active',
    nextBilling: 'January 15, 2025',
    features: {
      quizzesPerMonth: -1, // unlimited
      studentsPerQuiz: -1, // unlimited
      pdfExport: true,
      lmsIntegration: true,
      analytics: true,
      priority: true
    }
  });

  const [notificationPreferences, setNotificationPreferences] = useState({
    emailNotifications: true,
    quizShares: true,
    studentAttempts: true,
    systemUpdates: false,
    weeklyDigest: true,
    marketingEmails: false,
    pushNotifications: true,
    browserNotifications: false,
    smsNotifications: false
  });

  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'institution',
    allowDataCollection: false,
    shareAnalytics: false,
    allowQuizSharing: true,
    showInDirectory: true,
    allowContactFromStudents: true,
    dataRetention: '2years',
    cookiePreferences: 'functional'
  });

  const [integrations, setIntegrations] = useState({
    googledrive: { connected: true, lastSync: '2 hours ago' },
    moodle: { connected: false },
    canvas: { connected: false },
    blackboard: { connected: false },
    onedrive: { connected: false },
    zoom: { connected: false }
  });

  const tabs = [
    { id: 'profile', label: 'Profile', icon: 'User' },
    { id: 'security', label: 'Security', icon: 'Shield' },
    { id: 'notifications', label: 'Notifications', icon: 'Bell' },
    { id: 'subscription', label: 'Subscription', icon: 'CreditCard' },
    { id: 'privacy', label: 'Privacy', icon: 'Lock' },
    { id: 'integrations', label: 'Integrations', icon: 'Zap' },
    { id: 'export', label: 'Export Data', icon: 'Download' }
  ];

  const breadcrumbs = [
    { label: 'Dashboard', href: true, onClick: () => navigate('/teacher-dashboard') },
    { label: 'Account Settings' }
  ];

  useEffect(() => {
    // Mock authentication check
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
      navigate('/login');
      return;
    }
  }, [navigate]);

  const handleUpdateProfile = async (profileData) => {
    // Mock API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setUser(prev => ({ ...prev, ...profileData }));
    console.log('Profile updated:', profileData);
  };

  const handleChangePassword = async (passwordData) => {
    // Mock API call with validation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock validation - check current password
    if (passwordData?.currentPassword !== 'teacher123') {
      throw new Error('Current password is incorrect');
    }
    
    console.log('Password changed successfully');
  };

  const handleUpdateNotifications = async (preferences) => {
    // Mock API call
    await new Promise(resolve => setTimeout(resolve, 800));
    setNotificationPreferences(preferences);
    console.log('Notification preferences updated:', preferences);
  };

  const handleUpgradeSubscription = async (planId) => {
    // Mock API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setSubscription(prev => ({ ...prev, plan: planId }));
    console.log('Subscription upgraded to:', planId);
  };

  const handleManageBilling = async () => {
    // Mock billing portal redirect
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('Opening billing portal...');
  };

  const handleUpdatePrivacy = async (settings) => {
    // Mock API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setPrivacySettings(settings);
    console.log('Privacy settings updated:', settings);
  };

  const handleConnectIntegration = async (serviceId) => {
    // Mock integration connection
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIntegrations(prev => ({
      ...prev,
      [serviceId]: { connected: true, lastSync: 'Just now' }
    }));
    console.log(`Connected to ${serviceId}`);
  };

  const handleDisconnectIntegration = async (serviceId) => {
    // Mock integration disconnection
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIntegrations(prev => ({
      ...prev,
      [serviceId]: { connected: false }
    }));
    console.log(`Disconnected from ${serviceId}`);
  };

  const handleExportData = async (exportSettings) => {
    // Mock data export
    await new Promise(resolve => setTimeout(resolve, 3000));
    console.log('Data export completed:', exportSettings);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <ProfileSection
            user={user}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'security':
        return (
          <SecuritySection
            onChangePassword={handleChangePassword}
          />
        );
      case 'notifications':
        return (
          <NotificationSettings
            preferences={notificationPreferences}
            onUpdatePreferences={handleUpdateNotifications}
          />
        );
      case 'subscription':
        return (
          <SubscriptionSection
            subscription={subscription}
            onUpgrade={handleUpgradeSubscription}
            onManageBilling={handleManageBilling}
          />
        );
      case 'privacy':
        return (
          <PrivacySettings
            privacySettings={privacySettings}
            onUpdatePrivacy={handleUpdatePrivacy}
          />
        );
      case 'integrations':
        return (
          <IntegrationSettings
            integrations={integrations}
            onConnectIntegration={handleConnectIntegration}
            onDisconnectIntegration={handleDisconnectIntegration}
          />
        );
      case 'export':
        return (
          <ExportSection
            onExportData={handleExportData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        user={user}
        currentPath="/account-settings"
        onNavigate={navigate}
      />
      <div className="pt-16">
        <PageHeader
          title="Account Settings"
          subtitle="Manage your profile, security, and preferences"
          breadcrumbs={breadcrumbs}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Settings Navigation */}
            <div className="lg:w-64 flex-shrink-0">
              <div className="bg-card rounded-lg border border-border p-4">
                <nav className="space-y-2">
                  {tabs?.map((tab) => (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveTab(tab?.id)}
                      className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                        activeTab === tab?.id
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }`}
                    >
                      <Icon name={tab?.icon} size={16} />
                      <span>{tab?.label}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Settings Content */}
            <div className="flex-1">
              {renderTabContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;