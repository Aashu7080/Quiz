import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  const trustSignals = [
    {
      icon: 'Shield',
      title: 'Secure & Private',
      description: 'Your data is encrypted and protected with industry-standard security'
    },
    {
      icon: 'Users',
      title: '50,000+ Educators',
      description: 'Join thousands of teachers already using QuizCraft'
    },
    {
      icon: 'Award',
      title: 'Education Certified',
      description: 'Compliant with FERPA and other educational privacy standards'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'High School Teacher',
      content: `QuizCraft has revolutionized how I create assessments. What used to take hours now takes minutes!`,
      rating: 5
    },
    {
      name: 'Dr. Michael Chen',
      role: 'University Professor',
      content: `The AI-generated questions are surprisingly accurate and save me tremendous time.`,
      rating: 5
    }
  ];

  return (
    <div className="space-y-8">
      {/* Trust Signals */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {trustSignals?.map((signal, index) => (
          <div key={index} className="text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Icon name={signal?.icon} size={24} className="text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">{signal?.title}</h3>
            <p className="text-sm text-muted-foreground">{signal?.description}</p>
          </div>
        ))}
      </div>
      {/* Testimonials */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground text-center">
          Trusted by Educators Worldwide
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {testimonials?.map((testimonial, index) => (
            <div key={index} className="bg-muted/50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                {[...Array(testimonial?.rating)]?.map((_, i) => (
                  <Icon key={i} name="Star" size={16} className="text-warning fill-current" />
                ))}
              </div>
              <p className="text-sm text-foreground mb-3 italic">
                "{testimonial?.content}"
              </p>
              <div>
                <p className="font-medium text-foreground">{testimonial?.name}</p>
                <p className="text-xs text-muted-foreground">{testimonial?.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Security Badges */}
      <div className="flex items-center justify-center space-x-6 pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Lock" size={16} className="text-success" />
          <span className="text-xs text-muted-foreground">SSL Secured</span>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="Shield" size={16} className="text-success" />
          <span className="text-xs text-muted-foreground">FERPA Compliant</span>
        </div>
        <div className="flex items-center space-x-2">
          <Icon name="CheckCircle" size={16} className="text-success" />
          <span className="text-xs text-muted-foreground">Privacy Protected</span>
        </div>
      </div>
    </div>
  );
};

export default TrustSignals;