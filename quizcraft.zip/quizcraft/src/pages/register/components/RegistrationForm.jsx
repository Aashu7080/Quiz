import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const RegistrationForm = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: '',
    institutionName: '',
    gradeLevel: '',
    agreeToTerms: false
  });

  const [errors, setErrors] = useState({});
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const roleOptions = [
    { value: 'teacher', label: 'Teacher / Educator' },
    { value: 'student', label: 'Student / Learner' }
  ];

  const gradeLevelOptions = [
    { value: 'elementary', label: 'Elementary (K-5)' },
    { value: 'middle', label: 'Middle School (6-8)' },
    { value: 'high', label: 'High School (9-12)' },
    { value: 'college', label: 'College / University' },
    { value: 'graduate', label: 'Graduate School' },
    { value: 'other', label: 'Other' }
  ];

  const calculatePasswordStrength = (password) => {
    let strength = 0;
    if (password?.length >= 8) strength += 25;
    if (/[a-z]/?.test(password)) strength += 25;
    if (/[A-Z]/?.test(password)) strength += 25;
    if (/[0-9]/?.test(password) && /[^A-Za-z0-9]/?.test(password)) strength += 25;
    return strength;
  };

  const validateField = (name, value) => {
    const newErrors = { ...errors };

    switch (name) {
      case 'fullName':
        if (!value?.trim()) {
          newErrors.fullName = 'Full name is required';
        } else if (value?.trim()?.length < 2) {
          newErrors.fullName = 'Name must be at least 2 characters';
        } else {
          delete newErrors?.fullName;
        }
        break;

      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!value) {
          newErrors.email = 'Email is required';
        } else if (!emailRegex?.test(value)) {
          newErrors.email = 'Please enter a valid email address';
        } else {
          delete newErrors?.email;
        }
        break;

      case 'password':
        if (!value) {
          newErrors.password = 'Password is required';
        } else if (value?.length < 8) {
          newErrors.password = 'Password must be at least 8 characters';
        } else {
          delete newErrors?.password;
        }
        break;

      case 'confirmPassword':
        if (!value) {
          newErrors.confirmPassword = 'Please confirm your password';
        } else if (value !== formData?.password) {
          newErrors.confirmPassword = 'Passwords do not match';
        } else {
          delete newErrors?.confirmPassword;
        }
        break;

      case 'role':
        if (!value) {
          newErrors.role = 'Please select your role';
        } else {
          delete newErrors?.role;
        }
        break;

      case 'institutionName':
        if (formData?.role === 'teacher' && !value?.trim()) {
          newErrors.institutionName = 'Institution name is required for teachers';
        } else {
          delete newErrors?.institutionName;
        }
        break;

      case 'gradeLevel':
        if (formData?.role === 'student' && !value) {
          newErrors.gradeLevel = 'Grade level is required for students';
        } else {
          delete newErrors?.gradeLevel;
        }
        break;

      case 'agreeToTerms':
        if (!value) {
          newErrors.agreeToTerms = 'You must agree to the terms and conditions';
        } else {
          delete newErrors?.agreeToTerms;
        }
        break;

      default:
        break;
    }

    setErrors(newErrors);
  };

  const handleInputChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (name === 'password') {
      setPasswordStrength(calculatePasswordStrength(value));
      if (formData?.confirmPassword) {
        validateField('confirmPassword', formData?.confirmPassword);
      }
    }
    
    validateField(name, value);
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 25) return 'bg-error';
    if (passwordStrength < 50) return 'bg-warning';
    if (passwordStrength < 75) return 'bg-accent';
    return 'bg-success';
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength < 25) return 'Weak';
    if (passwordStrength < 50) return 'Fair';
    if (passwordStrength < 75) return 'Good';
    return 'Strong';
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    
    // Validate all fields
    Object.keys(formData)?.forEach(key => {
      validateField(key, formData?.[key]);
    });

    // Check if form is valid
    const hasErrors = Object.keys(errors)?.length > 0;
    const isFormComplete = formData?.fullName && formData?.email && formData?.password && 
                          formData?.confirmPassword && formData?.role && formData?.agreeToTerms &&
                          (formData?.role !== 'teacher' || formData?.institutionName) &&
                          (formData?.role !== 'student' || formData?.gradeLevel);

    if (!hasErrors && isFormComplete) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Full Name */}
      <Input
        label="Full Name"
        type="text"
        placeholder="Enter your full name"
        value={formData?.fullName}
        onChange={(e) => handleInputChange('fullName', e?.target?.value)}
        error={errors?.fullName}
        required
      />
      {/* Email */}
      <Input
        label="Email Address"
        type="email"
        placeholder="Enter your email address"
        value={formData?.email}
        onChange={(e) => handleInputChange('email', e?.target?.value)}
        error={errors?.email}
        required
      />
      {/* Role Selection */}
      <Select
        label="I am a..."
        placeholder="Select your role"
        options={roleOptions}
        value={formData?.role}
        onChange={(value) => handleInputChange('role', value)}
        error={errors?.role}
        required
      />
      {/* Conditional Fields */}
      {formData?.role === 'teacher' && (
        <Input
          label="Institution Name"
          type="text"
          placeholder="Enter your school or institution name"
          value={formData?.institutionName}
          onChange={(e) => handleInputChange('institutionName', e?.target?.value)}
          error={errors?.institutionName}
          required
        />
      )}
      {formData?.role === 'student' && (
        <Select
          label="Grade Level"
          placeholder="Select your grade level"
          options={gradeLevelOptions}
          value={formData?.gradeLevel}
          onChange={(value) => handleInputChange('gradeLevel', value)}
          error={errors?.gradeLevel}
          required
        />
      )}
      {/* Password */}
      <div className="relative">
        <Input
          label="Password"
          type={showPassword ? "text" : "password"}
          placeholder="Create a strong password"
          value={formData?.password}
          onChange={(e) => handleInputChange('password', e?.target?.value)}
          error={errors?.password}
          required
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-9 text-muted-foreground hover:text-foreground"
        >
          <Icon name={showPassword ? "EyeOff" : "Eye"} size={20} />
        </button>
        
        {/* Password Strength Indicator */}
        {formData?.password && (
          <div className="mt-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">Password strength</span>
              <span className={`text-xs font-medium ${
                passwordStrength < 25 ? 'text-error' :
                passwordStrength < 50 ? 'text-warning' :
                passwordStrength < 75 ? 'text-accent' : 'text-success'
              }`}>
                {getPasswordStrengthText()}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                style={{ width: `${passwordStrength}%` }}
              />
            </div>
          </div>
        )}
      </div>
      {/* Confirm Password */}
      <div className="relative">
        <Input
          label="Confirm Password"
          type={showConfirmPassword ? "text" : "password"}
          placeholder="Confirm your password"
          value={formData?.confirmPassword}
          onChange={(e) => handleInputChange('confirmPassword', e?.target?.value)}
          error={errors?.confirmPassword}
          required
        />
        <button
          type="button"
          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
          className="absolute right-3 top-9 text-muted-foreground hover:text-foreground"
        >
          <Icon name={showConfirmPassword ? "EyeOff" : "Eye"} size={20} />
        </button>
      </div>
      {/* Terms and Conditions */}
      <div className="space-y-2">
        <Checkbox
          label={
            <span className="text-sm">
              I agree to the{' '}
              <button type="button" className="text-primary hover:underline">
                Terms of Service
              </button>{' '}
              and{' '}
              <button type="button" className="text-primary hover:underline">
                Privacy Policy
              </button>
            </span>
          }
          checked={formData?.agreeToTerms}
          onChange={(e) => handleInputChange('agreeToTerms', e?.target?.checked)}
          error={errors?.agreeToTerms}
          required
        />
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        variant="default"
        size="lg"
        fullWidth
        loading={isLoading}
        iconName="UserPlus"
        iconPosition="left"
      >
        Create Account
      </Button>
    </form>
  );
};

export default RegistrationForm;