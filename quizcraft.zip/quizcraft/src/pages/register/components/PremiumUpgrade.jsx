import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const PremiumUpgrade = ({ onUpgrade, onSkip }) => {
  const [selectedPlan, setSelectedPlan] = useState('basic');

  const plans = [
    {
      id: 'basic',
      name: 'Basic',
      price: 'Free',
      period: 'Forever',
      features: [
        'Generate up to 10 quizzes per month',
        'Basic MCQ generation',
        'Standard quiz templates',
        'Email support'
      ],
      recommended: false
    },
    {
      id: 'premium',
      name: 'Premium',
      price: '$9.99',
      period: 'per month',
      features: [
        'Unlimited quiz generation',
        'Advanced AI question types',
        'PDF export functionality',
        'LMS integration (Moodle, Canvas)',
        'Analytics dashboard',
        'Priority support',
        'Custom branding'
      ],
      recommended: true
    },
    {
      id: 'institutional',
      name: 'Institutional',
      price: '$29.99',
      period: 'per month',
      features: [
        'Everything in Premium',
        'Multi-user management',
        'Advanced analytics',
        'Custom integrations',
        'Dedicated support',
        'Training sessions'
      ],
      recommended: false
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-foreground mb-2">
          Choose Your Plan
        </h3>
        <p className="text-muted-foreground">
          Start with our free plan or upgrade for advanced features
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {plans?.map((plan) => (
          <div
            key={plan?.id}
            className={`relative rounded-lg border-2 p-6 cursor-pointer transition-all duration-200 ${
              selectedPlan === plan?.id
                ? 'border-primary bg-primary/5' :'border-border bg-card hover:border-primary/50'
            } ${plan?.recommended ? 'ring-2 ring-primary/20' : ''}`}
            onClick={() => setSelectedPlan(plan?.id)}
          >
            {plan?.recommended && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                  Recommended
                </span>
              </div>
            )}

            <div className="text-center mb-4">
              <h4 className="text-lg font-semibold text-foreground">{plan?.name}</h4>
              <div className="mt-2">
                <span className="text-2xl font-bold text-foreground">{plan?.price}</span>
                {plan?.price !== 'Free' && (
                  <span className="text-muted-foreground ml-1">/{plan?.period}</span>
                )}
              </div>
            </div>

            <ul className="space-y-3 mb-6">
              {plan?.features?.map((feature, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <div className="flex items-center justify-center">
              <div className={`w-4 h-4 rounded-full border-2 ${
                selectedPlan === plan?.id
                  ? 'border-primary bg-primary' :'border-border'
              }`}>
                {selectedPlan === plan?.id && (
                  <div className="w-full h-full rounded-full bg-primary flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full" />
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <Button
          variant="outline"
          size="lg"
          onClick={onSkip}
          iconName="ArrowRight"
          iconPosition="right"
        >
          Continue with Basic
        </Button>
        {selectedPlan !== 'basic' && (
          <Button
            variant="default"
            size="lg"
            onClick={() => onUpgrade(selectedPlan)}
            iconName="Crown"
            iconPosition="left"
          >
            Upgrade to {plans?.find(p => p?.id === selectedPlan)?.name}
          </Button>
        )}
      </div>
      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          You can upgrade or downgrade your plan at any time from your account settings
        </p>
      </div>
    </div>
  );
};

export default PremiumUpgrade;