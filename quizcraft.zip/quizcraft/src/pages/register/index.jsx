import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import RegistrationForm from './components/RegistrationForm';
import SocialRegistration from './components/SocialRegistration';
import TrustSignals from './components/TrustSignals';
import PremiumUpgrade from './components/PremiumUpgrade';

const Register = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [registrationData, setRegistrationData] = useState(null);

  const steps = [
    { id: 1, title: 'Account Details', description: 'Create your account' },
    { id: 2, title: 'Choose Plan', description: 'Select your subscription' },
    { id: 3, title: 'Verification', description: 'Verify your email' }
  ];

  const handleRegistrationSubmit = async (formData) => {
    setIsLoading(true);
    
    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock registration success
      setRegistrationData(formData);
      setCurrentStep(2);
    } catch (error) {
      console.error('Registration failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialRegister = async (provider) => {
    setIsLoading(true);
    
    // Simulate social registration
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock social registration success
      const mockData = {
        fullName: provider === 'google' ? 'John Doe' : 'Jane Smith',
        email: provider === 'google' ? 'john.doe@gmail.com' : 'jane.smith@outlook.com',
        role: 'teacher',
        institutionName: 'Sample University'
      };
      
      setRegistrationData(mockData);
      setCurrentStep(2);
    } catch (error) {
      console.error('Social registration failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlanUpgrade = async (planId) => {
    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Navigate to appropriate dashboard based on role
      const dashboardPath = registrationData?.role === 'teacher' ?'/teacher-dashboard' :'/student-dashboard';
      
      navigate(dashboardPath);
    } catch (error) {
      console.error('Plan upgrade failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSkipUpgrade = () => {
    // Navigate to appropriate dashboard based on role
    const dashboardPath = registrationData?.role === 'teacher' ?'/teacher-dashboard' :'/student-dashboard';
    
    navigate(dashboardPath);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-8">
            <RegistrationForm 
              onSubmit={handleRegistrationSubmit}
              isLoading={isLoading}
            />
            
            <SocialRegistration 
              onSocialRegister={handleSocialRegister}
              isLoading={isLoading}
            />
          </div>
        );
      
      case 2:
        return (
          <PremiumUpgrade 
            onUpgrade={handlePlanUpgrade}
            onSkip={handleSkipUpgrade}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center cursor-pointer" onClick={() => navigate('/')}>
              <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center mr-3">
                <Icon name="BookOpen" size={20} color="white" />
              </div>
              <span className="text-xl font-semibold text-foreground">
                QuizCraft
              </span>
            </div>

            {/* Login Link */}
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Already have an account?</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/login')}
              >
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </header>
      <div className="flex min-h-[calc(100vh-4rem)]">
        {/* Left Side - Form */}
        <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
          <div className="w-full max-w-md space-y-8">
            {/* Progress Steps */}
            <div className="flex items-center justify-center space-x-4 mb-8">
              {steps?.map((step, index) => (
                <React.Fragment key={step?.id}>
                  <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      currentStep >= step?.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {currentStep > step?.id ? (
                        <Icon name="Check" size={16} />
                      ) : (
                        step?.id
                      )}
                    </div>
                    <div className="ml-2 hidden sm:block">
                      <p className={`text-sm font-medium ${
                        currentStep >= step?.id ? 'text-foreground' : 'text-muted-foreground'
                      }`}>
                        {step?.title}
                      </p>
                    </div>
                  </div>
                  {index < steps?.length - 1 && (
                    <div className={`w-8 h-0.5 ${
                      currentStep > step?.id ? 'bg-primary' : 'bg-muted'
                    }`} />
                  )}
                </React.Fragment>
              ))}
            </div>

            {/* Step Header */}
            <div className="text-center">
              <h1 className="text-2xl font-bold text-foreground">
                {steps?.find(s => s?.id === currentStep)?.title}
              </h1>
              <p className="mt-2 text-muted-foreground">
                {steps?.find(s => s?.id === currentStep)?.description}
              </p>
            </div>

            {/* Step Content */}
            {renderStepContent()}

            {/* Back Button */}
            {currentStep > 1 && (
              <div className="text-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentStep(currentStep - 1)}
                  iconName="ArrowLeft"
                  iconPosition="left"
                >
                  Back
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Right Side - Trust Signals */}
        <div className="hidden lg:flex lg:w-1/2 bg-muted/30 items-center justify-center p-12">
          <div className="max-w-lg">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                Join the QuizCraft Community
              </h2>
              <p className="text-muted-foreground">
                Transform your teaching with AI-powered quiz generation. 
                Create engaging assessments in minutes, not hours.
              </p>
            </div>
            
            <TrustSignals />
          </div>
        </div>
      </div>
      {/* Mobile Trust Signals */}
      <div className="lg:hidden bg-muted/30 px-4 sm:px-6 py-12">
        <div className="max-w-md mx-auto">
          <TrustSignals />
        </div>
      </div>
      {/* Footer */}
      <footer className="border-t border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <button className="hover:text-foreground transition-colors">
                Terms of Service
              </button>
              <button className="hover:text-foreground transition-colors">
                Privacy Policy
              </button>
              <button className="hover:text-foreground transition-colors">
                Help Center
              </button>
            </div>
            <div className="mt-4 sm:mt-0">
              <p className="text-sm text-muted-foreground">
                © {new Date()?.getFullYear()} QuizCraft. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Register;